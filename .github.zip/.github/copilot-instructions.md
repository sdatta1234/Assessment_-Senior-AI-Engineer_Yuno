# AI Agent Orchestration Platform - Development Guide

## Project Overview
Multi-agent AI orchestration platform with real-time monitoring, workflow builder, and external messaging integration.

## Tech Stack
- **Backend**: Node.js + Express + TypeScript
- **Frontend**: React + TypeScript + Vite
- **Database**: SQLite (development), PostgreSQL (production)
- **Agent Runtime**: Custom orchestration engine with LangGraph integration
- **Messaging**: Telegram integration (WhatsApp via Twilio)
- **Real-time**: WebSockets for live monitoring
- **Deployment**: Docker containerization

## Quick Start
```bash
# Install dependencies
npm install

# Start backend development server
npm run dev:backend

# Start frontend development server (in another terminal)
npm run dev:frontend

# Build for production
npm run build
```

## Project Structure
- `/backend` - Agent runtime, orchestration, APIs
- `/frontend` - React UI for agent management
- `/shared` - Shared types and utilities
- `/docs` - Architecture and deployment guides
- `docker-compose.yml` - Local development with services

## Development Status
- [ ] Backend scaffolding
- [ ] Frontend scaffolding
- [ ] Agent runtime implementation
- [ ] Database schema
- [ ] API endpoints
- [ ] Workflow builder
- [ ] Messaging integration
- [ ] Real-time monitoring
- [ ] Testing suite
- [ ] Documentation
