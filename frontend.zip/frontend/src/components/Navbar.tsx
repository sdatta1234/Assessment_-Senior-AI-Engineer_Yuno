import React from 'react'
import './Navbar.css'

export default function Navbar() {
  return (
    <nav className="navbar">
      <div className="navbar-brand">
        <h1>🤖 AI Agent Orchestration Platform</h1>
      </div>
      <div className="navbar-actions">
        <button className="btn-user">Profile</button>
        <button className="btn-logout">Logout</button>
      </div>
    </nav>
  )
}
