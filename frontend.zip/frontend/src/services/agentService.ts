import axios, { AxiosInstance } from 'axios';
import { Agent, AgentTool } from '@shared/types';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';

export class AgentService {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: `${API_BASE_URL}/agents`,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Add auth token to requests
    this.client.interceptors.request.use((config) => {
      const token = localStorage.getItem('authToken');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    });
  }

  /**
   * List all agents with pagination
   */
  async listAgents(page: number = 1, limit: number = 20): Promise<{ agents: Agent[]; total: number }> {
    const response = await this.client.get('/', {
      params: { page, limit },
    });
    return {
      agents: response.data.data,
      total: response.data.total,
    };
  }

  /**
   * Create a new agent
   */
  async createAgent(agent: Partial<Agent>): Promise<Agent> {
    const response = await this.client.post('/', agent);
    return response.data.data;
  }

  /**
   * Get agent by ID
   */
  async getAgent(agentId: string): Promise<Agent> {
    const response = await this.client.get(`/${agentId}`);
    return response.data.data;
  }

  /**
   * Update an agent
   */
  async updateAgent(agentId: string, updates: Partial<Agent>): Promise<Agent> {
    const response = await this.client.put(`/${agentId}`, updates);
    return response.data.data;
  }

  /**
   * Delete an agent
   */
  async deleteAgent(agentId: string): Promise<void> {
    await this.client.delete(`/${agentId}`);
  }

  /**
   * Get agent statistics
   */
  async getAgentStats(agentId: string): Promise<any> {
    const response = await this.client.get(`/${agentId}/stats`);
    return response.data.data;
  }
}

export default new AgentService();
