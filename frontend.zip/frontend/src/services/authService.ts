import axios, { AxiosInstance } from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';

export interface AuthTokens {
  token: string;
  user: {
    id: string;
    email: string;
    name: string;
  };
}

export class AuthService {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: `${API_BASE_URL}/auth`,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  }

  /**
   * Register a new user
   */
  async register(email: string, password: string, name: string): Promise<AuthTokens> {
    const response = await this.client.post('/register', { email, password, name });
    const { token, user } = response.data.data;
    localStorage.setItem('authToken', token);
    localStorage.setItem('user', JSON.stringify(user));
    return { token, user };
  }

  /**
   * Login user
   */
  async login(email: string, password: string): Promise<AuthTokens> {
    const response = await this.client.post('/login', { email, password });
    const { token, user } = response.data.data;
    localStorage.setItem('authToken', token);
    localStorage.setItem('user', JSON.stringify(user));
    return { token, user };
  }

  /**
   * Logout user
   */
  async logout(): Promise<void> {
    await this.client.post('/logout');
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
  }

  /**
   * Get current user
   */
  async getCurrentUser(): Promise<{ userId: string; email: string }> {
    const token = localStorage.getItem('authToken');
    if (!token) {
      throw new Error('No auth token found');
    }
    const response = await this.client.get('/me', {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data.data;
  }

  /**
   * Check if user is logged in
   */
  isLoggedIn(): boolean {
    return !!localStorage.getItem('authToken');
  }

  /**
   * Get stored auth token
   */
  getToken(): string | null {
    return localStorage.getItem('authToken');
  }

  /**
   * Get stored user info
   */
  getUser(): any | null {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
  }
}

export default new AuthService();
