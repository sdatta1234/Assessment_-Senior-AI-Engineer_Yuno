import axios, { AxiosInstance } from 'axios';
import { Message } from '@shared/types';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';

export class MessageService {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: `${API_BASE_URL}/messages`,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Add auth token to requests
    this.client.interceptors.request.use((config) => {
      const token = localStorage.getItem('authToken');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    });
  }

  /**
   * Get messages with optional filters
   */
  async getMessages(options?: {
    agentId?: string;
    channel?: string;
    limit?: number;
  }): Promise<Message[]> {
    const response = await this.client.get('/', {
      params: options,
    });
    return response.data.data;
  }

  /**
   * Send a message to an agent
   */
  async sendMessage(
    content: string,
    toAgentId: string,
    options?: {
      channel?: string;
      role?: 'user' | 'assistant' | 'system';
    }
  ): Promise<Message> {
    const response = await this.client.post('/', {
      content,
      toAgentId,
      channel: options?.channel || 'internal',
      role: options?.role || 'user',
    });
    return response.data.data;
  }

  /**
   * Get conversation by ID (workflow run)
   */
  async getConversation(conversationId: string): Promise<Message[]> {
    const response = await this.client.get(`/${conversationId}`);
    return response.data.data;
  }
}

export default new MessageService();
