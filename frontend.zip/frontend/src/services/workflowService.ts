import axios, { AxiosInstance } from 'axios';
import { Workflow, WorkflowRun } from '@shared/types';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';

export class WorkflowService {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: `${API_BASE_URL}/workflows`,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Add auth token to requests
    this.client.interceptors.request.use((config) => {
      const token = localStorage.getItem('authToken');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    });
  }

  /**
   * List all workflows with pagination
   */
  async listWorkflows(page: number = 1, limit: number = 20): Promise<{ workflows: Workflow[]; total: number }> {
    const response = await this.client.get('/', {
      params: { page, limit },
    });
    return {
      workflows: response.data.data,
      total: response.data.total,
    };
  }

  /**
   * Create a new workflow
   */
  async createWorkflow(workflow: Partial<Workflow>): Promise<Workflow> {
    const response = await this.client.post('/', workflow);
    return response.data.data;
  }

  /**
   * Get workflow by ID
   */
  async getWorkflow(workflowId: string): Promise<Workflow> {
    const response = await this.client.get(`/${workflowId}`);
    return response.data.data;
  }

  /**
   * Update a workflow
   */
  async updateWorkflow(workflowId: string, updates: Partial<Workflow>): Promise<Workflow> {
    const response = await this.client.put(`/${workflowId}`, updates);
    return response.data.data;
  }

  /**
   * Delete a workflow
   */
  async deleteWorkflow(workflowId: string): Promise<void> {
    await this.client.delete(`/${workflowId}`);
  }

  /**
   * Execute a workflow
   */
  async executeWorkflow(workflowId: string, input?: any): Promise<WorkflowRun> {
    const response = await this.client.post(`/${workflowId}/execute`, { input });
    return response.data.data;
  }

  /**
   * Get workflow runs
   */
  async getWorkflowRuns(workflowId: string): Promise<WorkflowRun[]> {
    const response = await this.client.get(`/${workflowId}/runs`);
    return response.data.data;
  }
}

export default new WorkflowService();
