import create from 'zustand';
import authService from '../services/authService';

interface AuthStore {
  isLoggedIn: boolean;
  user: any | null;
  loading: boolean;
  error: string | null;
  register: (email: string, password: string, name: string) => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  checkAuth: () => void;
}

export const useAuthStore = create<AuthStore>((set) => ({
  isLoggedIn: false,
  user: null,
  loading: false,
  error: null,

  register: async (email: string, password: string, name: string) => {
    set({ loading: true, error: null });
    try {
      const { token, user } = await authService.register(email, password, name);
      set({
        isLoggedIn: true,
        user,
        loading: false,
      });
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to register',
        loading: false,
      });
    }
  },

  login: async (email: string, password: string) => {
    set({ loading: true, error: null });
    try {
      const { token, user } = await authService.login(email, password);
      set({
        isLoggedIn: true,
        user,
        loading: false,
      });
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to login',
        loading: false,
      });
    }
  },

  logout: async () => {
    set({ loading: true, error: null });
    try {
      await authService.logout();
      set({
        isLoggedIn: false,
        user: null,
        loading: false,
      });
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to logout',
        loading: false,
      });
    }
  },

  checkAuth: () => {
    const isLoggedIn = authService.isLoggedIn();
    const user = authService.getUser();
    set({ isLoggedIn, user });
  },
}));
