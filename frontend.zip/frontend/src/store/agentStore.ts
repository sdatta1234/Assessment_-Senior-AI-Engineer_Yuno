import create from 'zustand';
import { Agent } from '@shared/types';
import agentService from '../services/agentService';

interface AgentStore {
  agents: Agent[];
  loading: boolean;
  error: string | null;
  fetchAgents: (page?: number, limit?: number) => Promise<void>;
  createAgent: (agent: Partial<Agent>) => Promise<void>;
  updateAgent: (agentId: string, updates: Partial<Agent>) => Promise<void>;
  deleteAgent: (agentId: string) => Promise<void>;
  setAgents: (agents: Agent[]) => void;
  addAgent: (agent: Agent) => void;
  removeAgent: (agentId: string) => void;
}

export const useAgentStore = create<AgentStore>((set) => ({
  agents: [],
  loading: false,
  error: null,

  fetchAgents: async (page = 1, limit = 20) => {
    set({ loading: true, error: null });
    try {
      const { agents } = await agentService.listAgents(page, limit);
      set({ agents, loading: false });
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to fetch agents',
        loading: false,
      });
    }
  },

  createAgent: async (agent: Partial<Agent>) => {
    set({ loading: true, error: null });
    try {
      const newAgent = await agentService.createAgent(agent);
      set((state) => ({
        agents: [...state.agents, newAgent],
        loading: false,
      }));
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to create agent',
        loading: false,
      });
    }
  },

  updateAgent: async (agentId: string, updates: Partial<Agent>) => {
    set({ loading: true, error: null });
    try {
      const updated = await agentService.updateAgent(agentId, updates);
      set((state) => ({
        agents: state.agents.map((a) => (a.id === agentId ? updated : a)),
        loading: false,
      }));
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to update agent',
        loading: false,
      });
    }
  },

  deleteAgent: async (agentId: string) => {
    set({ loading: true, error: null });
    try {
      await agentService.deleteAgent(agentId);
      set((state) => ({
        agents: state.agents.filter((a) => a.id !== agentId),
        loading: false,
      }));
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to delete agent',
        loading: false,
      });
    }
  },

  setAgents: (agents: Agent[]) => set({ agents }),
  addAgent: (agent: Agent) => set((state) => ({ agents: [...state.agents, agent] })),
  removeAgent: (agentId: string) =>
    set((state) => ({
      agents: state.agents.filter((a) => a.id !== agentId),
    })),
}));
