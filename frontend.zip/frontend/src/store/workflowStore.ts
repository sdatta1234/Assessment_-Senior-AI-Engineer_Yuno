import create from 'zustand';
import { Workflow, WorkflowRun } from '@shared/types';
import workflowService from '../services/workflowService';

interface WorkflowStore {
  workflows: Workflow[];
  runs: WorkflowRun[];
  loading: boolean;
  error: string | null;
  fetchWorkflows: (page?: number, limit?: number) => Promise<void>;
  createWorkflow: (workflow: Partial<Workflow>) => Promise<void>;
  updateWorkflow: (workflowId: string, updates: Partial<Workflow>) => Promise<void>;
  deleteWorkflow: (workflowId: string) => Promise<void>;
  executeWorkflow: (workflowId: string, input?: any) => Promise<void>;
  fetchWorkflowRuns: (workflowId: string) => Promise<void>;
  setWorkflows: (workflows: Workflow[]) => void;
  addWorkflow: (workflow: Workflow) => void;
  removeWorkflow: (workflowId: string) => void;
}

export const useWorkflowStore = create<WorkflowStore>((set) => ({
  workflows: [],
  runs: [],
  loading: false,
  error: null,

  fetchWorkflows: async (page = 1, limit = 20) => {
    set({ loading: true, error: null });
    try {
      const { workflows } = await workflowService.listWorkflows(page, limit);
      set({ workflows, loading: false });
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to fetch workflows',
        loading: false,
      });
    }
  },

  createWorkflow: async (workflow: Partial<Workflow>) => {
    set({ loading: true, error: null });
    try {
      const newWorkflow = await workflowService.createWorkflow(workflow);
      set((state) => ({
        workflows: [...state.workflows, newWorkflow],
        loading: false,
      }));
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to create workflow',
        loading: false,
      });
    }
  },

  updateWorkflow: async (workflowId: string, updates: Partial<Workflow>) => {
    set({ loading: true, error: null });
    try {
      const updated = await workflowService.updateWorkflow(workflowId, updates);
      set((state) => ({
        workflows: state.workflows.map((w) => (w.id === workflowId ? updated : w)),
        loading: false,
      }));
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to update workflow',
        loading: false,
      });
    }
  },

  deleteWorkflow: async (workflowId: string) => {
    set({ loading: true, error: null });
    try {
      await workflowService.deleteWorkflow(workflowId);
      set((state) => ({
        workflows: state.workflows.filter((w) => w.id !== workflowId),
        loading: false,
      }));
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to delete workflow',
        loading: false,
      });
    }
  },

  executeWorkflow: async (workflowId: string, input?: any) => {
    set({ loading: true, error: null });
    try {
      await workflowService.executeWorkflow(workflowId, input);
      set({ loading: false });
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to execute workflow',
        loading: false,
      });
    }
  },

  fetchWorkflowRuns: async (workflowId: string) => {
    set({ loading: true, error: null });
    try {
      const runs = await workflowService.getWorkflowRuns(workflowId);
      set({ runs, loading: false });
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Failed to fetch workflow runs',
        loading: false,
      });
    }
  },

  setWorkflows: (workflows: Workflow[]) => set({ workflows }),
  addWorkflow: (workflow: Workflow) =>
    set((state) => ({
      workflows: [...state.workflows, workflow],
    })),
  removeWorkflow: (workflowId: string) =>
    set((state) => ({
      workflows: state.workflows.filter((w) => w.id !== workflowId),
    })),
}));
