import React, { useState, useEffect } from 'react';
import { getWebSocketClient } from '../services/websocketClient';

export default function Monitoring() {
  const [metrics, setMetrics] = useState({
    activeAgents: 0,
    totalMessages: 0,
    avgLatency: 0,
    successRate: 100,
  });
  const [logs, setLogs] = useState<string[]>([
    '[INFO] System initialized',
    '[INFO] Database connected',
    '[INFO] WebSocket server running',
  ]);

  useEffect(() => {
    const ws = getWebSocketClient();

    // Connect to WebSocket
    ws.connect().catch(() => {
      console.log('WebSocket connection failed');
    });

    // Listen for events
    const unsubscribeAgent = ws.on('agent:created', (data) => {
      setMetrics((prev) => ({ ...prev, activeAgents: prev.activeAgents + 1 }));
      addLog(`[INFO] Agent created: ${data.name}`);
    });

    const unsubscribeMessage = ws.on('message:sent', (data) => {
      setMetrics((prev) => ({ ...prev, totalMessages: prev.totalMessages + 1 }));
      addLog(`[INFO] Message sent to ${data.toAgentId}`);
    });

    const unsubscribeWorkflow = ws.on('workflow:executed', (data) => {
      addLog(`[INFO] Workflow executed: ${data.workflowId}`);
    });

    return () => {
      unsubscribeAgent();
      unsubscribeMessage();
      unsubscribeWorkflow();
    };
  }, []);

  const addLog = (message: string) => {
    setLogs((prev) => [...prev, `${new Date().toISOString()} ${message}`].slice(-100));
  };

  return (
    <div>
      <h1>Monitoring & Analytics</h1>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px', marginTop: '20px' }}>
        <div style={{ padding: '20px', backgroundColor: '#f0f9ff', borderRadius: '8px', border: '1px solid #bfdbfe' }}>
          <p style={{ color: '#1e40af', fontSize: '14px', marginBottom: '8px', margin: 0 }}>Active Agents</p>
          <p style={{ fontSize: '32px', fontWeight: 'bold', margin: 0 }}>{metrics.activeAgents}</p>
          <p style={{ fontSize: '0.85em', color: '#666', margin: '5px 0 0 0' }}>Running</p>
        </div>
        <div style={{ padding: '20px', backgroundColor: '#f0fdf4', borderRadius: '8px', border: '1px solid #bbf7d0' }}>
          <p style={{ color: '#166534', fontSize: '14px', marginBottom: '8px', margin: 0 }}>Total Messages</p>
          <p style={{ fontSize: '32px', fontWeight: 'bold', margin: 0 }}>{metrics.totalMessages}</p>
          <p style={{ fontSize: '0.85em', color: '#666', margin: '5px 0 0 0' }}>Processed</p>
        </div>
        <div style={{ padding: '20px', backgroundColor: '#fef3c7', borderRadius: '8px', border: '1px solid #fcd34d' }}>
          <p style={{ color: '#92400e', fontSize: '14px', marginBottom: '8px', margin: 0 }}>Avg Latency</p>
          <p style={{ fontSize: '32px', fontWeight: 'bold', margin: 0 }}>{metrics.avgLatency}ms</p>
          <p style={{ fontSize: '0.85em', color: '#666', margin: '5px 0 0 0' }}>Response time</p>
        </div>
        <div style={{ padding: '20px', backgroundColor: '#f0fdf4', borderRadius: '8px', border: '1px solid #bbf7d0' }}>
          <p style={{ color: '#166534', fontSize: '14px', marginBottom: '8px', margin: 0 }}>Success Rate</p>
          <p style={{ fontSize: '32px', fontWeight: 'bold', margin: 0, color: '#22c55e' }}>{metrics.successRate}%</p>
          <p style={{ fontSize: '0.85em', color: '#666', margin: '5px 0 0 0' }}>Operations</p>
        </div>
      </div>

      <div style={{ marginTop: '30px', padding: '20px', backgroundColor: '#f9fafb', borderRadius: '8px', border: '1px solid #ddd' }}>
        <h2 style={{ marginBottom: '16px', margin: 0 }}>System Logs</h2>
        <div
          style={{
            backgroundColor: '#1f2937',
            color: '#90ee90',
            fontFamily: 'monospace',
            padding: '16px',
            borderRadius: '4px',
            maxHeight: '400px',
            overflow: 'auto',
            fontSize: '0.85em',
            lineHeight: 1.6,
          }}
        >
          {logs.length === 0 ? (
            <p style={{ color: '#999' }}>No logs available</p>
          ) : (
            logs.map((log, i) => (
              <div key={i}>
                {log}
              </div>
            ))
          )}
        </div>
      </div>

      <div style={{ marginTop: '20px', padding: '16px', backgroundColor: '#f0f9ff', borderRadius: '8px', border: '1px solid #bfdbfe' }}>
        <h3 style={{ margin: '0 0 10px 0' }}>Real-time Information</h3>
        <ul style={{ margin: 0, paddingLeft: '20px', lineHeight: 1.8 }}>
          <li>Monitoring updates via WebSocket in real-time</li>
          <li>Agent status tracked automatically</li>
          <li>Message flow monitored continuously</li>
          <li>Logs captured and stored for debugging</li>
        </ul>
      </div>
    </div>
  );
}
