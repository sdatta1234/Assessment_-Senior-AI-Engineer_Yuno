import React, { useEffect, useState } from 'react';
import { useAgentStore } from '../store/agentStore';
import { useWorkflowStore } from '../store/workflowStore';
import { getWebSocketClient } from '../services/websocketClient';

export default function Dashboard() {
  const { agents } = useAgentStore();
  const { workflows } = useWorkflowStore();
  const [health, setHealth] = useState({ status: 'healthy' });
  const [metrics, setMetrics] = useState({ activeAgents: 0, memory: {} });

  useEffect(() => {
    // Subscribe to WebSocket events
    const ws = getWebSocketClient();
    
    const unsubscribeAgent = ws.on('agent:created', () => {
      console.log('Agent created');
    });

    const unsubscribeWorkflow = ws.on('workflow:executed', () => {
      console.log('Workflow executed');
    });

    // Try to connect
    ws.connect().catch(() => console.log('WebSocket not available'));

    return () => {
      unsubscribeAgent();
      unsubscribeWorkflow();
    };
  }, []);

  return (
    <div>
      <h1>Dashboard</h1>
      <p>Welcome to the AI Agent Orchestration Platform</p>
      <div className="grid" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginTop: '20px' }}>
        <div className="card" style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px', backgroundColor: '#f0f9ff' }}>
          <h2 style={{ margin: '0 0 10px 0', color: '#0066cc' }}>Active Agents</h2>
          <p style={{ fontSize: '32px', fontWeight: 'bold', margin: 0 }}>{agents.length}</p>
          <p style={{ fontSize: '0.9em', color: '#666', margin: '5px 0 0 0' }}>Agents ready</p>
        </div>
        <div className="card" style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px', backgroundColor: '#f0fdf4' }}>
          <h2 style={{ margin: '0 0 10px 0', color: '#22c55e' }}>Running Workflows</h2>
          <p style={{ fontSize: '32px', fontWeight: 'bold', margin: 0 }}>{workflows.length}</p>
          <p style={{ fontSize: '0.9em', color: '#666', margin: '5px 0 0 0' }}>Workflows available</p>
        </div>
        <div className="card" style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px', backgroundColor: '#fef3c7' }}>
          <h2 style={{ margin: '0 0 10px 0', color: '#ca8a04' }}>API Endpoints</h2>
          <p style={{ fontSize: '32px', fontWeight: 'bold', margin: 0 }}>6</p>
          <p style={{ fontSize: '0.9em', color: '#666', margin: '5px 0 0 0' }}>Routes available</p>
        </div>
        <div className="card" style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px', backgroundColor: '#f0fdf4' }}>
          <h2 style={{ margin: '0 0 10px 0', color: '#22c55e' }}>System Health</h2>
          <p style={{ fontSize: '32px', fontWeight: 'bold', margin: 0, color: '#22c55e' }}>✓ Healthy</p>
          <p style={{ fontSize: '0.9em', color: '#666', margin: '5px 0 0 0' }}>All systems operational</p>
        </div>
      </div>

      <div style={{ marginTop: '30px', padding: '20px', backgroundColor: '#f9fafb', borderRadius: '8px', border: '1px solid #ddd' }}>
        <h3>Quick Start</h3>
        <ul style={{ lineHeight: 1.8 }}>
          <li>Create your first agent in the <strong>Agents</strong> page</li>
          <li>Build workflows in the <strong>Workflows</strong> page</li>
          <li>Monitor real-time activity in <strong>Monitoring</strong></li>
          <li>Configure settings in <strong>Settings</strong></li>
        </ul>
      </div>
    </div>
  );
}
