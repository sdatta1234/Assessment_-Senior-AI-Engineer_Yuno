import React, { useState } from 'react'

export default function Settings() {
  const [settings, setSettings] = useState({
    apiKey: '',
    telegramBot: '',
    twilioAccount: '',
    webhookUrl: ''
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setSettings(prev => ({ ...prev, [name]: value }))
  }

  const handleSave = () => {
    console.log('Settings saved:', settings)
  }

  return (
    <div>
      <h1>Settings</h1>

      <div style={{ maxWidth: '600px', marginTop: '20px' }}>
        <div style={{ marginBottom: '20px' }}>
          <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500' }}>
            OpenAI API Key
          </label>
          <input
            type="password"
            name="apiKey"
            value={settings.apiKey}
            onChange={handleChange}
            placeholder="sk-..."
            style={{ width: '100%', padding: '8px', border: '1px solid #ddd', borderRadius: '4px' }}
          />
        </div>

        <div style={{ marginBottom: '20px' }}>
          <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500' }}>
            Telegram Bot Token
          </label>
          <input
            type="password"
            name="telegramBot"
            value={settings.telegramBot}
            onChange={handleChange}
            placeholder="123456:ABC..."
            style={{ width: '100%', padding: '8px', border: '1px solid #ddd', borderRadius: '4px' }}
          />
        </div>

        <div style={{ marginBottom: '20px' }}>
          <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500' }}>
            Twilio Account SID
          </label>
          <input
            type="password"
            name="twilioAccount"
            value={settings.twilioAccount}
            onChange={handleChange}
            placeholder="AC..."
            style={{ width: '100%', padding: '8px', border: '1px solid #ddd', borderRadius: '4px' }}
          />
        </div>

        <div style={{ marginBottom: '20px' }}>
          <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500' }}>
            Webhook URL
          </label>
          <input
            type="text"
            name="webhookUrl"
            value={settings.webhookUrl}
            onChange={handleChange}
            placeholder="https://your-domain.com/webhook"
            style={{ width: '100%', padding: '8px', border: '1px solid #ddd', borderRadius: '4px' }}
          />
        </div>

        <button
          onClick={handleSave}
          style={{
            padding: '10px 20px',
            backgroundColor: '#0066cc',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
            fontSize: '14px',
            fontWeight: '500'
          }}
        >
          Save Settings
        </button>
      </div>
    </div>
  )
}
