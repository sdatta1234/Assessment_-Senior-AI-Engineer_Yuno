# Deployment Guide

## Local Development

### Prerequisites
- Node.js 18+
- npm or yarn
- Git

### Setup

1. **Clone the repository**
```bash
git clone <repository-url>
cd ai-agent-orchestration-platform
```

2. **Install dependencies**
```bash
npm install
```

3. **Create environment file**
```bash
cp .env.example .env
```

4. **Edit .env with your configuration**
```env
NODE_ENV=development
PORT=3000
DATABASE_URL=sqlite:./dev.db

OPENAI_API_KEY=sk-your-key-here
TELEGRAM_BOT_TOKEN=your-bot-token
```

5. **Start development servers**
```bash
# Terminal 1: Start all services
npm run dev

# OR start individually
npm run dev:backend    # Backend on http://localhost:3000
npm run dev:frontend   # Frontend on http://localhost:5173
```

6. **Access the application**
- Frontend: http://localhost:5173
- Backend API: http://localhost:3000
- API Documentation: http://localhost:3000/api/docs

## Docker Deployment

### Using Docker Compose (Recommended for development)

1. **Build and start services**
```bash
npm run docker:build
npm run docker:up
```

2. **Access services**
- Frontend: http://localhost:5173
- Backend API: http://localhost:3000

3. **View logs**
```bash
docker-compose logs -f backend
docker-compose logs -f frontend
```

4. **Stop services**
```bash
npm run docker:down
```

### Custom Docker Build

1. **Build individual images**
```bash
docker build -f backend.Dockerfile -t ai-orchestration-backend:latest .
docker build -f frontend.Dockerfile -t ai-orchestration-frontend:latest .
```

2. **Run containers**
```bash
# Backend
docker run -d \
  -p 3000:3000 \
  -e OPENAI_API_KEY=sk-your-key \
  -e TELEGRAM_BOT_TOKEN=your-token \
  ai-orchestration-backend:latest

# Frontend
docker run -d \
  -p 5173:5173 \
  ai-orchestration-frontend:latest
```

## Production Deployment

### Database Setup

#### PostgreSQL

1. **Create database**
```bash
createdb agent_db
```

2. **Set connection string**
```bash
DATABASE_URL=postgresql://user:password@localhost:5432/agent_db
```

3. **Run migrations**
```bash
npm --workspace=backend run migrate
```

### Environment Variables

Set these for production:
```env
NODE_ENV=production
PORT=3000
DATABASE_URL=postgresql://user:password@host:5432/agent_db

JWT_SECRET=long-random-string-min-32-chars
JWT_EXPIRATION=7d

OPENAI_API_KEY=sk-prod-key
LLM_MODEL=gpt-4
LLM_TEMPERATURE=0.7

TELEGRAM_BOT_TOKEN=prod-bot-token
TELEGRAM_WEBHOOK_URL=https://your-domain.com/webhook

TWILIO_ACCOUNT_SID=prod-account-sid
TWILIO_AUTH_TOKEN=prod-auth-token
TWILIO_PHONE_NUMBER=+1234567890

# Frontend
VITE_API_URL=https://api.your-domain.com
VITE_WS_URL=wss://api.your-domain.com
```

### Kubernetes Deployment

#### 1. Create ConfigMap
```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: ai-orchestration-config
data:
  NODE_ENV: "production"
  LLM_MODEL: "gpt-4"
```

#### 2. Create Secrets
```yaml
apiVersion: v1
kind: Secret
metadata:
  name: ai-orchestration-secrets
type: Opaque
data:
  JWT_SECRET: base64-encoded-secret
  OPENAI_API_KEY: base64-encoded-key
  TELEGRAM_BOT_TOKEN: base64-encoded-token
```

#### 3. Deploy Backend
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-orchestration-backend
spec:
  replicas: 3
  selector:
    matchLabels:
      app: ai-orchestration-backend
  template:
    metadata:
      labels:
        app: ai-orchestration-backend
    spec:
      containers:
      - name: backend
        image: ai-orchestration-backend:latest
        ports:
        - containerPort: 3000
        envFrom:
        - configMapRef:
            name: ai-orchestration-config
        - secretRef:
            name: ai-orchestration-secrets
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 10
          periodSeconds: 10
```

#### 4. Deploy Frontend
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-orchestration-frontend
spec:
  replicas: 2
  selector:
    matchLabels:
      app: ai-orchestration-frontend
  template:
    metadata:
      labels:
        app: ai-orchestration-frontend
    spec:
      containers:
      - name: frontend
        image: ai-orchestration-frontend:latest
        ports:
        - containerPort: 5173
        env:
        - name: VITE_API_URL
          value: "https://api.your-domain.com"
        resources:
          requests:
            memory: "128Mi"
            cpu: "100m"
          limits:
            memory: "256Mi"
            cpu: "250m"
```

#### 5. Create Services
```yaml
apiVersion: v1
kind: Service
metadata:
  name: ai-orchestration-backend
spec:
  selector:
    app: ai-orchestration-backend
  ports:
  - protocol: TCP
    port: 3000
    targetPort: 3000
  type: ClusterIP

---
apiVersion: v1
kind: Service
metadata:
  name: ai-orchestration-frontend
spec:
  selector:
    app: ai-orchestration-frontend
  ports:
  - protocol: TCP
    port: 80
    targetPort: 5173
  type: LoadBalancer
```

### Cloud Platforms

#### AWS Deployment

1. **Push images to ECR**
```bash
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin <account-id>.dkr.ecr.us-east-1.amazonaws.com

docker tag ai-orchestration-backend:latest <account-id>.dkr.ecr.us-east-1.amazonaws.com/ai-orchestration-backend:latest
docker push <account-id>.dkr.ecr.us-east-1.amazonaws.com/ai-orchestration-backend:latest
```

2. **Deploy on ECS/Fargate**
```bash
aws ecs create-service \
  --cluster ai-orchestration \
  --service-name backend \
  --task-definition ai-orchestration-backend:1 \
  --desired-count 3
```

#### Heroku Deployment

1. **Install Heroku CLI**
```bash
npm install -g heroku
heroku login
```

2. **Create app**
```bash
heroku create ai-orchestration-backend
heroku create ai-orchestration-frontend
```

3. **Set environment variables**
```bash
heroku config:set OPENAI_API_KEY=sk-your-key --app ai-orchestration-backend
heroku config:set TELEGRAM_BOT_TOKEN=your-token --app ai-orchestration-backend
```

4. **Deploy**
```bash
git push heroku main
```

### SSL/TLS Setup

#### Using Let's Encrypt with Nginx

1. **Install Certbot**
```bash
sudo apt-get install certbot python3-certbot-nginx
```

2. **Obtain certificate**
```bash
sudo certbot certonly --nginx -d api.your-domain.com
```

3. **Configure Nginx**
```nginx
server {
    listen 443 ssl http2;
    server_name api.your-domain.com;

    ssl_certificate /etc/letsencrypt/live/api.your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.your-domain.com/privkey.pem;

    location / {
        proxy_pass http://backend:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
```

## Monitoring

### Health Checks

```bash
curl http://localhost:3000/health
```

### Logs

**Development**
```bash
npm run dev:backend 2>&1 | tee logs/backend.log
```

**Docker**
```bash
docker-compose logs -f backend
```

**Kubernetes**
```bash
kubectl logs -f deployment/ai-orchestration-backend
```

### Metrics

- CPU usage
- Memory consumption
- Request latency
- Database connections
- Agent execution time

## Scaling

### Horizontal Scaling
- API is stateless (no session affinity needed)
- Use load balancer (nginx, HAProxy, AWS ALB)
- Database connection pooling required

### Vertical Scaling
- Increase container resource limits
- Database indexing on frequently queried columns
- Redis caching for frequently accessed data

## Backup & Recovery

### Database Backups

```bash
# PostgreSQL
pg_dump -U user agent_db > backup.sql

# Restore
psql -U user agent_db < backup.sql
```

### Automated Backups
```bash
# Using pg_basebackup
pg_basebackup -D /backup/$(date +%Y%m%d_%H%M%S) -Ft -z -P
```

## Troubleshooting

### Backend won't start
```bash
# Check Node version
node --version  # Should be 18+

# Check port availability
lsof -i :3000

# Clear node_modules
rm -rf node_modules
npm install
```

### Database errors
```bash
# Reset database
rm dev.db
npm --workspace=backend run migrate

# Check PostgreSQL connection
psql -h localhost -U user agent_db -c "SELECT 1"
```

### Frontend build fails
```bash
# Clear build cache
npm run build:frontend -- --force

# Check Node version
npm run build:frontend -- --version
```

## Security Checklist

- [ ] Change all default passwords
- [ ] Set strong JWT secret (32+ chars)
- [ ] Enable HTTPS/SSL in production
- [ ] Configure CORS for frontend domain
- [ ] Set up firewall rules
- [ ] Enable database encryption
- [ ] Configure backup retention
- [ ] Set up monitoring and alerts
- [ ] Regular security updates
- [ ] API rate limiting enabled

## Rollback Plan

```bash
# Docker rollback
docker-compose down
docker-compose pull
docker-compose up -d

# Kubernetes rollback
kubectl rollout history deployment/ai-orchestration-backend
kubectl rollout undo deployment/ai-orchestration-backend
```
