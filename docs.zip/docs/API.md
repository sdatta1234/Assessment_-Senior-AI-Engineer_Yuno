# API Documentation

## Base URL
```
http://localhost:3000/api
```

## Authentication
All endpoints (except `/auth/register` and `/auth/login`) require JWT token in Authorization header:
```
Authorization: Bearer <token>
```

## Response Format
All responses follow this format:
```json
{
  "success": boolean,
  "data": {},
  "error": "error message if failed",
  "message": "additional context"
}
```

## Endpoints

### Authentication

#### Register User
```
POST /auth/register
```
**Body:**
```json
{
  "email": "user@example.com",
  "password": "password123",
  "name": "User Name"
}
```

#### Login
```
POST /auth/login
```
**Body:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```
**Response:**
```json
{
  "success": true,
  "data": {
    "token": "jwt-token",
    "user": {
      "id": "user-id",
      "email": "user@example.com",
      "name": "User Name"
    }
  }
}
```

#### Get Current User
```
GET /auth/me
```

---

### Agents

#### List Agents
```
GET /agents
```
**Query Parameters:**
- `page`: Page number (default: 1)
- `limit`: Items per page (default: 20)
- `search`: Search by name/role

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "agent-1",
      "name": "Research Bot",
      "role": "researcher",
      "model": "gpt-4",
      "temperature": 0.7,
      "tools": ["web_search", "pdf_reader"],
      "channels": ["telegram"],
      "createdAt": "2024-01-15T10:00:00Z",
      "updatedAt": "2024-01-15T10:00:00Z"
    }
  ]
}
```

#### Create Agent
```
POST /agents
```
**Body:**
```json
{
  "name": "Research Bot",
  "role": "researcher",
  "description": "Searches and summarizes research papers",
  "systemPrompt": "You are a research assistant...",
  "model": "gpt-4",
  "temperature": 0.7,
  "maxTokens": 2000,
  "tools": [
    {
      "name": "web_search",
      "description": "Search the web for information",
      "parameters": {
        "query": "string",
        "limit": "number"
      }
    }
  ],
  "channels": ["telegram"],
  "memory": {
    "type": "hybrid",
    "maxSize": 10000
  },
  "guardrails": [
    {
      "type": "rate_limit",
      "value": 10,
      "description": "Max 10 calls per minute"
    }
  ]
}
```

#### Get Agent
```
GET /agents/:id
```

#### Update Agent
```
PUT /agents/:id
```
**Body:** (same structure as create)

#### Delete Agent
```
DELETE /agents/:id
```

---

### Workflows

#### List Workflows
```
GET /workflows
```
**Query Parameters:**
- `page`: Page number (default: 1)
- `limit`: Items per page (default: 20)

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "workflow-1",
      "name": "Research Pipeline",
      "description": "Multi-agent research workflow",
      "nodes": [
        {
          "id": "node-1",
          "type": "agent",
          "data": {
            "label": "Research Agent",
            "agentId": "agent-1"
          }
        }
      ],
      "edges": [
        {
          "id": "edge-1",
          "source": "node-1",
          "target": "node-2"
        }
      ]
    }
  ]
}
```

#### Create Workflow
```
POST /workflows
```
**Body:**
```json
{
  "name": "Research Pipeline",
  "description": "Multi-agent research workflow",
  "nodes": [
    {
      "id": "trigger-1",
      "type": "trigger",
      "data": {
        "label": "Start",
        "config": {
          "type": "manual"
        }
      }
    },
    {
      "id": "agent-1",
      "type": "agent",
      "data": {
        "label": "Research Agent",
        "agentId": "agent-1"
      }
    },
    {
      "id": "end-1",
      "type": "end",
      "data": {
        "label": "End"
      }
    }
  ],
  "edges": [
    {
      "id": "edge-1",
      "source": "trigger-1",
      "target": "agent-1"
    },
    {
      "id": "edge-2",
      "source": "agent-1",
      "target": "end-1"
    }
  ]
}
```

#### Execute Workflow
```
POST /workflows/:id/execute
```
**Body:**
```json
{
  "input": "Research the latest AI trends",
  "parameters": {}
}
```
**Response:**
```json
{
  "success": true,
  "data": {
    "runId": "run-123",
    "workflowId": "workflow-1",
    "status": "running",
    "startedAt": "2024-01-15T10:00:00Z"
  }
}
```

#### Get Workflow Runs
```
GET /workflows/:id/runs
```
**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "run-123",
      "workflowId": "workflow-1",
      "status": "completed",
      "startedAt": "2024-01-15T10:00:00Z",
      "completedAt": "2024-01-15T10:05:00Z",
      "results": {
        "output": "..."
      }
    }
  ]
}
```

---

### Messages

#### Get Message History
```
GET /messages
```
**Query Parameters:**
- `agentId`: Filter by agent
- `channel`: Filter by channel
- `limit`: Number of messages (default: 50)

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "msg-1",
      "fromAgentId": "agent-1",
      "toAgentId": "agent-2",
      "channel": "internal",
      "content": "Please research this topic",
      "role": "user",
      "createdAt": "2024-01-15T10:00:00Z"
    }
  ]
}
```

#### Send Message
```
POST /messages
```
**Body:**
```json
{
  "toAgentId": "agent-1",
  "channel": "telegram",
  "content": "Hello, can you help?",
  "role": "user"
}
```

#### Get Conversation
```
GET /messages/:conversationId
```

---

### Monitoring

#### Get System Logs (WebSocket)
```
WebSocket Connection: ws://localhost:3000/monitoring/logs
```
**Subscribe:**
```json
{
  "type": "subscribe",
  "channel": "logs"
}
```
**Incoming Events:**
```json
{
  "type": "log:entry",
  "payload": {
    "level": "info",
    "service": "agent-runtime",
    "message": "Agent executed successfully",
    "timestamp": "2024-01-15T10:00:00Z"
  }
}
```

#### Get System Metrics
```
GET /monitoring/metrics
```
**Response:**
```json
{
  "success": true,
  "data": {
    "cpu": 25.5,
    "memory": 512,
    "uptime": 3600,
    "activeAgents": 2,
    "totalMessages": 145,
    "avgLatency": 250
  }
}
```

#### Get Agent Statistics
```
GET /monitoring/agents/:agentId/stats
```
**Response:**
```json
{
  "success": true,
  "data": {
    "agentId": "agent-1",
    "tokensUsed": 5000,
    "cost": 0.15,
    "successRate": 95.5,
    "averageResponseTime": 1200,
    "totalExecutions": 100
  }
}
```

---

## Error Codes

| Code | Description |
|------|-------------|
| 400  | Bad Request - Invalid parameters |
| 401  | Unauthorized - Missing/invalid token |
| 403  | Forbidden - Insufficient permissions |
| 404  | Not Found - Resource not found |
| 409  | Conflict - Resource already exists |
| 500  | Server Error - Internal error |

## Rate Limiting
- Default: 100 requests per minute
- Limit header: `X-RateLimit-Remaining`

## Examples

### Create and Execute a Workflow
```bash
# 1. Create an agent
curl -X POST http://localhost:3000/api/agents \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Research Bot",
    "role": "researcher",
    "systemPrompt": "You are a research assistant",
    "model": "gpt-4",
    "tools": []
  }'

# 2. Create a workflow
curl -X POST http://localhost:3000/api/workflows \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Research Pipeline",
    "nodes": [...],
    "edges": [...]
  }'

# 3. Execute the workflow
curl -X POST http://localhost:3000/api/workflows/{workflowId}/execute \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "input": "Research the latest AI trends"
  }'
```
