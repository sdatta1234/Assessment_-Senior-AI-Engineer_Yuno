# Contributing Guidelines

## Code of Conduct
Be respectful, inclusive, and constructive in all interactions.

## Getting Started

### 1. Fork and Clone
```bash
git clone https://github.com/yourusername/ai-agent-orchestration-platform.git
cd ai-agent-orchestration-platform
git remote add upstream https://github.com/original/ai-agent-orchestration-platform.git
```

### 2. Create Feature Branch
```bash
git checkout -b feature/your-feature-name
```

### 3. Install Dependencies
```bash
npm install
```

### 4. Start Development
```bash
npm run dev
```

## Development Workflow

### Code Style
- Use TypeScript for type safety
- Follow ESLint rules (run `npm run lint`)
- Use 2-space indentation
- Use meaningful variable/function names

### Creating an Agent

1. **Define agent configuration**
```typescript
// backend/src/agents/examples/researcher.ts
export const researcherAgent = {
  name: 'Research Bot',
  role: 'researcher',
  systemPrompt: 'You are a research assistant...',
  model: 'gpt-4',
  tools: ['web_search', 'summarize']
}
```

2. **Register in agent factory**
```typescript
// backend/src/agents/factory.ts
import { researcherAgent } from './examples/researcher'

export const agentTemplates = {
  'researcher': researcherAgent,
  // ... other agents
}
```

3. **Add UI in frontend**
```typescript
// frontend/src/components/AgentTemplates/ResearcherTemplate.tsx
export function ResearcherTemplate() {
  return (
    <div>
      <h3>Research Bot</h3>
      <p>Searches and summarizes research papers</p>
      <button>Use Template</button>
    </div>
  )
}
```

### Adding a New Messaging Channel

1. **Create adapter**
```typescript
// backend/src/messaging/adapters/slack.ts
export class SlackAdapter implements MessagingAdapter {
  async sendMessage(message: Message): Promise<void> {
    // Implementation
  }
  
  async handleIncoming(payload: any): Promise<void> {
    // Implementation
  }
}
```

2. **Register adapter**
```typescript
// backend/src/messaging/registry.ts
import { SlackAdapter } from './adapters/slack'

export const adapters = {
  'slack': new SlackAdapter(),
  'telegram': new TelegramAdapter(),
  // ...
}
```

3. **Update agent configuration UI**
```typescript
// frontend/src/pages/Settings.tsx
const channels = ['telegram', 'whatsapp', 'slack', /* add new channel */]
```

### Creating a Workflow Template

1. **Define template**
```typescript
// backend/src/workflows/templates/research.ts
export const researchTemplate = {
  name: 'Research Pipeline',
  description: 'Multi-agent research workflow',
  nodes: [
    { id: 'trigger', type: 'trigger', data: { label: 'Start' } },
    { id: 'research', type: 'agent', data: { label: 'Research', agentId: 'research-bot' } },
    { id: 'summarize', type: 'agent', data: { label: 'Summarize', agentId: 'summary-bot' } },
    { id: 'end', type: 'end', data: { label: 'End' } }
  ],
  edges: [
    { id: 'e1', source: 'trigger', target: 'research' },
    { id: 'e2', source: 'research', target: 'summarize' },
    { id: 'e3', source: 'summarize', target: 'end' }
  ]
}
```

2. **Register template**
```typescript
// backend/src/workflows/templates/index.ts
export const workflowTemplates = {
  'research': researchTemplate,
  // ... other templates
}
```

3. **Add UI component**
```typescript
// frontend/src/components/WorkflowTemplates/ResearchPipeline.tsx
```

## Testing

### Run Tests
```bash
npm test
```

### Backend Tests
```bash
npm run test:backend
npm run test:backend -- --coverage
```

### Frontend Tests
```bash
npm run test:frontend
```

### Writing Tests

**Backend test example:**
```typescript
// backend/src/agents/agent.test.ts
import { createAgent } from './agent'

describe('Agent Creation', () => {
  test('should create agent with valid config', () => {
    const agent = createAgent({
      name: 'Test Agent',
      role: 'test',
      systemPrompt: 'Test',
      model: 'gpt-4'
    })
    
    expect(agent).toBeDefined()
    expect(agent.name).toBe('Test Agent')
  })
})
```

## Commit Guidelines

### Commit Message Format
```
type(scope): subject

body

footer
```

**Types:**
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `style`: Code style changes
- `refactor`: Code refactoring
- `test`: Test additions
- `chore`: Build/dependency changes

**Examples:**
```
feat(agents): add custom tool execution
fix(workflows): resolve state machine bug
docs(api): update endpoint documentation
```

## Pull Request Process

1. **Update your branch**
```bash
git fetch upstream
git rebase upstream/main
```

2. **Push changes**
```bash
git push origin feature/your-feature-name
```

3. **Create Pull Request**
- Write clear description of changes
- Reference related issues
- Include screenshots for UI changes
- Ensure all tests pass

4. **Address Review Comments**
```bash
# Make changes
git add .
git commit --amend
git push -f origin feature/your-feature-name
```

## Documentation

### Adding Documentation
1. Keep README.md updated
2. Add docstrings to functions/classes
3. Update API documentation
4. Include examples in docs/

### Documentation Template
```typescript
/**
 * Creates a new agent with the specified configuration
 * 
 * @param config - Agent configuration object
 * @param config.name - Display name of the agent
 * @param config.role - Role/purpose of the agent
 * @param config.systemPrompt - System message for the agent
 * @returns The created agent instance
 * @throws AgentCreationError if configuration is invalid
 * 
 * @example
 * const agent = createAgent({
 *   name: 'Research Bot',
 *   role: 'researcher',
 *   systemPrompt: 'You are a research assistant...'
 * })
 */
export function createAgent(config: AgentConfig): Agent {
  // Implementation
}
```

## Performance Guidelines

- Use async/await instead of callbacks
- Implement connection pooling for databases
- Cache frequently accessed data
- Minimize WebSocket message size
- Optimize database queries with indexes

## Security Guidelines

- Validate all user inputs
- Use parameterized queries
- Sanitize HTML content
- Use environment variables for secrets
- Implement proper error handling (don't expose internals)

## Deployment

### Staging Deployment
```bash
git push origin develop
# CI/CD pipeline automatically deploys to staging
```

### Production Deployment
```bash
# Create release
npm version patch  # or minor, major

# Push and create release on GitHub
git push origin main --tags
```

## Getting Help

- Check [API documentation](./API.md)
- Review [Architecture](./ARCHITECTURE.md)
- Look at existing code patterns
- Ask in GitHub issues
- Check project discussions

## Review Process

PRs require:
- ✅ All tests passing
- ✅ Code coverage maintained
- ✅ No linting errors
- ✅ At least 1 approval
- ✅ Updated documentation

Maintainers typically review within 48 hours.

## Roadmap

### Phase 1 (Current)
- [x] Project scaffolding
- [x] Basic API endpoints
- [ ] Agent execution engine
- [ ] Database layer implementation

### Phase 2
- [ ] Workflow builder UI
- [ ] Real-time monitoring
- [ ] Telegram integration
- [ ] WhatsApp integration

### Phase 3
- [ ] Advanced agent memory
- [ ] Marketplace/templates
- [ ] Performance optimization
- [ ] Enterprise features

See [PROJECT.md](./PROJECT.md) for detailed roadmap.

## License

By contributing, you agree that your contributions will be licensed under the MIT License.

## Thank You!

We appreciate your contributions to making this project better! 🙏
