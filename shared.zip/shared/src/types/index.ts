// Agent Types
export interface Agent {
  id: string;
  name: string;
  role: string;
  description?: string;
  systemPrompt: string;
  model: string;
  temperature?: number;
  maxTokens?: number;
  tools: AgentTool[];
  channels: string[]; // telegram, whatsapp, slack, etc.
  schedule?: AgentSchedule;
  memory?: AgentMemory;
  guardrails?: Guardrail[];
  createdAt: Date;
  updatedAt: Date;
}

export interface AgentTool {
  id: string;
  name: string;
  description: string;
  parameters: Record<string, any>;
  type: 'function' | 'api' | 'integration';
}

export interface AgentSchedule {
  type: 'once' | 'interval' | 'cron';
  value: string; // e.g., "0 0 * * *" for cron
}

export interface AgentMemory {
  type: 'shortterm' | 'longterm' | 'hybrid';
  maxSize: number; // in tokens or messages
  ttl?: number; // time to live in seconds
}

export interface Guardrail {
  id: string;
  type: 'rate_limit' | 'cost_limit' | 'token_limit' | 'content_filter';
  value: any;
  description?: string;
}

// Workflow Types
export interface Workflow {
  id: string;
  name: string;
  description?: string;
  nodes: WorkflowNode[];
  edges: WorkflowEdge[];
  metadata?: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface WorkflowNode {
  id: string;
  type: 'agent' | 'trigger' | 'condition' | 'parallel' | 'end';
  data: {
    label: string;
    agentId?: string;
    config?: Record<string, any>;
  };
}

export interface WorkflowEdge {
  id: string;
  source: string;
  target: string;
  condition?: string; // conditional logic
}

export interface WorkflowRun {
  id: string;
  workflowId: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  startedAt: Date;
  completedAt?: Date;
  messages: Message[];
  results?: Record<string, any>;
}

// Message Types
export interface Message {
  id: string;
  workflowRunId?: string;
  fromAgentId?: string;
  toAgentId?: string;
  channel?: string; // 'telegram', 'whatsapp', 'internal', etc.
  content: string;
  role: 'user' | 'assistant' | 'system';
  metadata?: Record<string, any>;
  createdAt: Date;
}

// User & Auth Types
export interface User {
  id: string;
  email: string;
  passwordHash: string;
  name: string;
  role: 'admin' | 'user';
  createdAt: Date;
  updatedAt: Date;
}

// WebSocket Event Types
export type WSEventType = 
  | 'agent:created'
  | 'agent:updated'
  | 'agent:deleted'
  | 'workflow:started'
  | 'workflow:completed'
  | 'message:sent'
  | 'log:entry'
  | 'monitoring:update';

export interface WSEvent {
  type: WSEventType;
  payload: any;
  timestamp: Date;
}

// API Response Types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
}

// Monitoring Types
export interface MonitoringMetric {
  id: string;
  agentId: string;
  metricType: 'tokens_used' | 'cost' | 'latency' | 'success_rate';
  value: number;
  timestamp: Date;
}

export interface SystemLog {
  id: string;
  level: 'debug' | 'info' | 'warn' | 'error';
  service: string;
  message: string;
  metadata?: Record<string, any>;
  timestamp: Date;
}
