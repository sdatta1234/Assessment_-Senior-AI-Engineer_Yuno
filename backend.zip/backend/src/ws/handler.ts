import { WebSocketServer, WebSocket } from 'ws';
import { WSEvent, WSEventType } from '../../shared/src/types';

const clients = new Set<WebSocket>();

export function setupWebSocket(wss: WebSocketServer): void {
  wss.on('connection', (ws: WebSocket) => {
    console.log('✓ WebSocket client connected');
    clients.add(ws);

    ws.on('message', (data: string) => {
      try {
        const message = JSON.parse(data);
        handleMessage(message, ws);
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      console.log('✓ WebSocket client disconnected');
      clients.delete(ws);
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });
  });
}

function handleMessage(message: any, ws: WebSocket): void {
  const { type, payload } = message;
  
  switch (type) {
    case 'subscribe':
      console.log(`Client subscribed to: ${payload.channel}`);
      break;
    case 'unsubscribe':
      console.log(`Client unsubscribed from: ${payload.channel}`);
      break;
    default:
      console.log(`Received message type: ${type}`);
  }
}

export function broadcastEvent(event: WSEvent): void {
  const data = JSON.stringify(event);
  clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(data);
    }
  });
}

export function broadcastToChannel(channel: string, event: any): void {
  const wsEvent: WSEvent = {
    type: event.type as WSEventType,
    payload: event.payload,
    timestamp: new Date()
  };
  broadcastEvent(wsEvent);
}
