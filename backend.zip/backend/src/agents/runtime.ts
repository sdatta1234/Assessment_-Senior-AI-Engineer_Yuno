import { v4 as uuidv4 } from 'uuid';
import { Agent, AgentTool } from '@shared/types';

export interface AgentState {
  agentId: string;
  role: string;
  messages: Array<{ role: 'user' | 'assistant' | 'system'; content: string }>;
  memory: Map<string, any>;
  tools: Map<string, AgentTool>;
  executionCount: number;
  lastExecuted?: Date;
  status: 'idle' | 'executing' | 'error';
}

export interface ToolExecutionResult {
  toolName: string;
  success: boolean;
  result?: any;
  error?: string;
}

export class AgentRuntime {
  private agents: Map<string, AgentState> = new Map();
  private toolRegistry: Map<string, (params: any) => Promise<any>> = new Map();

  constructor() {
    this.registerDefaultTools();
  }

  /**
   * Initialize an agent with configuration
   */
  initializeAgent(agent: Agent): AgentState {
    const state: AgentState = {
      agentId: agent.id,
      role: agent.role,
      messages: [
        {
          role: 'system',
          content: agent.systemPrompt,
        },
      ],
      memory: new Map(),
      tools: new Map(),
      executionCount: 0,
      status: 'idle',
    };

    // Register agent tools
    if (agent.tools && agent.tools.length > 0) {
      agent.tools.forEach((tool) => {
        state.tools.set(tool.name, tool);
      });
    }

    this.agents.set(agent.id, state);
    return state;
  }

  /**
   * Get agent state
   */
  getAgent(agentId: string): AgentState | undefined {
    return this.agents.get(agentId);
  }

  /**
   * Add message to agent's message history
   */
  addMessage(agentId: string, role: 'user' | 'assistant' | 'system', content: string): void {
    const agent = this.agents.get(agentId);
    if (agent) {
      agent.messages.push({ role, content });
      // Keep memory bounded to last 50 messages
      if (agent.messages.length > 50) {
        agent.messages = agent.messages.slice(-50);
      }
    }
  }

  /**
   * Execute a tool for the agent
   */
  async executeTool(agentId: string, toolName: string, params: any): Promise<ToolExecutionResult> {
    try {
      const agent = this.agents.get(agentId);
      if (!agent) {
        return {
          toolName,
          success: false,
          error: `Agent ${agentId} not found`,
        };
      }

      const tool = agent.tools.get(toolName);
      if (!tool) {
        return {
          toolName,
          success: false,
          error: `Tool ${toolName} not found for agent`,
        };
      }

      // Get tool executor
      const executor = this.toolRegistry.get(toolName);
      if (!executor) {
        return {
          toolName,
          success: false,
          error: `No executor registered for tool ${toolName}`,
        };
      }

      // Execute tool
      agent.status = 'executing';
      const result = await executor(params);
      agent.executionCount++;
      agent.lastExecuted = new Date();
      agent.status = 'idle';

      // Log to memory
      agent.memory.set(`tool_${Date.now()}`, {
        tool: toolName,
        params,
        result,
        timestamp: new Date(),
      });

      return {
        toolName,
        success: true,
        result,
      };
    } catch (error) {
      const agent = this.agents.get(agentId);
      if (agent) {
        agent.status = 'error';
      }

      return {
        toolName,
        success: false,
        error: error instanceof Error ? error.message : String(error),
      };
    }
  }

  /**
   * Register a tool executor function
   */
  registerTool(name: string, executor: (params: any) => Promise<any>): void {
    this.toolRegistry.set(name, executor);
  }

  /**
   * Register default tools
   */
  private registerDefaultTools(): void {
    // Echo tool - returns input
    this.registerTool('echo', async (params: any) => {
      return { echoed: params.message || params };
    });

    // Sleep tool - delays execution
    this.registerTool('sleep', async (params: any) => {
      const ms = params.milliseconds || 1000;
      await new Promise((resolve) => setTimeout(resolve, ms));
      return { sleptMs: ms };
    });

    // Calculate tool - simple math
    this.registerTool('calculate', async (params: any) => {
      try {
        const result = eval(params.expression);
        return { result, expression: params.expression };
      } catch (error) {
        return { error: 'Invalid expression' };
      }
    });

    // Memory store tool
    this.registerTool('store_memory', async (params: any) => {
      return {
        stored: true,
        key: params.key,
        value: params.value,
      };
    });

    // Memory recall tool
    this.registerTool('recall_memory', async (params: any) => {
      return {
        key: params.key,
        value: params.value,
      };
    });
  }

  /**
   * Get agent's message history
   */
  getMessageHistory(agentId: string): Array<{ role: 'user' | 'assistant' | 'system'; content: string }> {
    const agent = this.agents.get(agentId);
    return agent ? agent.messages : [];
  }

  /**
   * Get agent's memory
   */
  getMemory(agentId: string): Record<string, any> {
    const agent = this.agents.get(agentId);
    if (!agent) return {};

    const memory: Record<string, any> = {};
    agent.memory.forEach((value, key) => {
      memory[key] = value;
    });
    return memory;
  }

  /**
   * Set memory value
   */
  setMemory(agentId: string, key: string, value: any): void {
    const agent = this.agents.get(agentId);
    if (agent) {
      agent.memory.set(key, value);
    }
  }

  /**
   * Cleanup agent
   */
  deleteAgent(agentId: string): void {
    this.agents.delete(agentId);
  }

  /**
   * Get all active agents
   */
  getActiveAgents(): string[] {
    return Array.from(this.agents.keys());
  }

  /**
   * Get agent statistics
   */
  getAgentStats(agentId: string) {
    const agent = this.agents.get(agentId);
    if (!agent) return null;

    return {
      agentId,
      role: agent.role,
      status: agent.status,
      executionCount: agent.executionCount,
      messageCount: agent.messages.length,
      memorySize: agent.memory.size,
      lastExecuted: agent.lastExecuted,
      tools: Array.from(agent.tools.keys()),
    };
  }
}

// Singleton instance
let runtimeInstance: AgentRuntime | null = null;

export function getAgentRuntime(): AgentRuntime {
  if (!runtimeInstance) {
    runtimeInstance = new AgentRuntime();
  }
  return runtimeInstance;
}

export function resetAgentRuntime(): void {
  runtimeInstance = null;
}
