import { Database } from 'sqlite3';
import { v4 as uuidv4 } from 'uuid';
import { Workflow, WorkflowRun } from '@shared/types';

export class WorkflowRepository {
  constructor(private db: Database) {}

  async create(workflow: Omit<Workflow, 'id' | 'createdAt' | 'updatedAt'>): Promise<Workflow> {
    const id = uuidv4();
    const now = new Date().toISOString();

    return new Promise((resolve, reject) => {
      this.db.run(
        `INSERT INTO workflows (id, name, description, nodes, edges, metadata, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id,
          workflow.name,
          workflow.description || null,
          JSON.stringify(workflow.nodes),
          JSON.stringify(workflow.edges),
          JSON.stringify(workflow.metadata || {}),
          now,
          now,
        ],
        async (err) => {
          if (err) reject(err);
          else {
            const created = await this.findById(id);
            resolve(created!);
          }
        }
      );
    });
  }

  async findById(id: string): Promise<Workflow | null> {
    return new Promise((resolve, reject) => {
      this.db.get(
        'SELECT * FROM workflows WHERE id = ?',
        [id],
        (err, row: any) => {
          if (err) reject(err);
          else resolve(row ? this.mapRowToWorkflow(row) : null);
        }
      );
    });
  }

  async findAll(limit: number = 100, offset: number = 0): Promise<Workflow[]> {
    return new Promise((resolve, reject) => {
      this.db.all(
        'SELECT * FROM workflows ORDER BY created_at DESC LIMIT ? OFFSET ?',
        [limit, offset],
        (err, rows: any[]) => {
          if (err) reject(err);
          else resolve((rows || []).map((row) => this.mapRowToWorkflow(row)));
        }
      );
    });
  }

  async update(id: string, updates: Partial<Workflow>): Promise<Workflow> {
    const now = new Date().toISOString();
    const fields: string[] = [];
    const values: any[] = [];

    if (updates.name !== undefined) {
      fields.push('name = ?');
      values.push(updates.name);
    }
    if (updates.nodes !== undefined) {
      fields.push('nodes = ?');
      values.push(JSON.stringify(updates.nodes));
    }
    if (updates.edges !== undefined) {
      fields.push('edges = ?');
      values.push(JSON.stringify(updates.edges));
    }

    fields.push('updated_at = ?');
    values.push(now);
    values.push(id);

    return new Promise((resolve, reject) => {
      this.db.run(
        `UPDATE workflows SET ${fields.join(', ')} WHERE id = ?`,
        values,
        async (err) => {
          if (err) reject(err);
          else {
            const updated = await this.findById(id);
            resolve(updated!);
          }
        }
      );
    });
  }

  async delete(id: string): Promise<void> {
    return new Promise((resolve, reject) => {
      this.db.run('DELETE FROM workflows WHERE id = ?', [id], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });
  }

  private mapRowToWorkflow(row: any): Workflow {
    return {
      id: row.id,
      name: row.name,
      description: row.description,
      nodes: JSON.parse(row.nodes),
      edges: JSON.parse(row.edges),
      metadata: JSON.parse(row.metadata || '{}'),
      createdAt: new Date(row.created_at),
      updatedAt: new Date(row.updated_at),
    };
  }
}

export class WorkflowRunRepository {
  constructor(private db: Database) {}

  async create(workflowId: string): Promise<WorkflowRun> {
    const id = uuidv4();
    const now = new Date().toISOString();

    return new Promise((resolve, reject) => {
      this.db.run(
        `INSERT INTO workflow_runs (id, workflow_id, status, started_at) VALUES (?, ?, ?, ?)`,
        [id, workflowId, 'pending', now],
        async (err) => {
          if (err) reject(err);
          else {
            const created = await this.findById(id);
            resolve(created!);
          }
        }
      );
    });
  }

  async findById(id: string): Promise<WorkflowRun | null> {
    return new Promise((resolve, reject) => {
      this.db.get(
        'SELECT * FROM workflow_runs WHERE id = ?',
        [id],
        (err, row: any) => {
          if (err) reject(err);
          else resolve(row ? this.mapRowToRun(row) : null);
        }
      );
    });
  }

  async findByWorkflowId(workflowId: string, limit: number = 50): Promise<WorkflowRun[]> {
    return new Promise((resolve, reject) => {
      this.db.all(
        'SELECT * FROM workflow_runs WHERE workflow_id = ? ORDER BY started_at DESC LIMIT ?',
        [workflowId, limit],
        (err, rows: any[]) => {
          if (err) reject(err);
          else resolve((rows || []).map((row) => this.mapRowToRun(row)));
        }
      );
    });
  }

  async updateStatus(id: string, status: string): Promise<void> {
    return new Promise((resolve, reject) => {
      const completedAt = status === 'completed' || status === 'failed' ? new Date().toISOString() : null;
      const updateQuery = completedAt
        ? 'UPDATE workflow_runs SET status = ?, completed_at = ? WHERE id = ?'
        : 'UPDATE workflow_runs SET status = ? WHERE id = ?';

      const params = completedAt ? [status, completedAt, id] : [status, id];

      this.db.run(updateQuery, params, (err) => {
        if (err) reject(err);
        else resolve();
      });
    });
  }

  private mapRowToRun(row: any): WorkflowRun {
    return {
      id: row.id,
      workflowId: row.workflow_id,
      status: row.status as 'pending' | 'running' | 'completed' | 'failed',
      startedAt: new Date(row.started_at),
      completedAt: row.completed_at ? new Date(row.completed_at) : undefined,
      messages: [],
      results: row.results ? JSON.parse(row.results) : undefined,
    };
  }
}
