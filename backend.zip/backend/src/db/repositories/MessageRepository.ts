import { Database } from 'sqlite3';
import { v4 as uuidv4 } from 'uuid';
import { Message } from '@shared/types';

export class MessageRepository {
  constructor(private db: Database) {}

  async create(message: Omit<Message, 'id' | 'createdAt'>): Promise<Message> {
    const id = uuidv4();
    const now = new Date().toISOString();

    return new Promise((resolve, reject) => {
      this.db.run(
        `INSERT INTO messages (
          id, workflow_run_id, from_agent_id, to_agent_id, channel, content, role, metadata, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id,
          message.workflowRunId || null,
          message.fromAgentId || null,
          message.toAgentId || null,
          message.channel || 'internal',
          message.content,
          message.role,
          JSON.stringify(message.metadata || {}),
          now,
        ],
        async (err) => {
          if (err) reject(err);
          else {
            const created = await this.findById(id);
            resolve(created!);
          }
        }
      );
    });
  }

  async findById(id: string): Promise<Message | null> {
    return new Promise((resolve, reject) => {
      this.db.get(
        'SELECT * FROM messages WHERE id = ?',
        [id],
        (err, row: any) => {
          if (err) reject(err);
          else resolve(row ? this.mapRowToMessage(row) : null);
        }
      );
    });
  }

  async findByWorkflowRunId(workflowRunId: string, limit: number = 100): Promise<Message[]> {
    return new Promise((resolve, reject) => {
      this.db.all(
        'SELECT * FROM messages WHERE workflow_run_id = ? ORDER BY created_at ASC LIMIT ?',
        [workflowRunId, limit],
        (err, rows: any[]) => {
          if (err) reject(err);
          else resolve((rows || []).map((row) => this.mapRowToMessage(row)));
        }
      );
    });
  }

  async findByAgentId(agentId: string, limit: number = 50): Promise<Message[]> {
    return new Promise((resolve, reject) => {
      this.db.all(
        `SELECT * FROM messages 
         WHERE from_agent_id = ? OR to_agent_id = ? 
         ORDER BY created_at DESC LIMIT ?`,
        [agentId, agentId, limit],
        (err, rows: any[]) => {
          if (err) reject(err);
          else resolve((rows || []).map((row) => this.mapRowToMessage(row)));
        }
      );
    });
  }

  async findByChannel(channel: string, limit: number = 100): Promise<Message[]> {
    return new Promise((resolve, reject) => {
      this.db.all(
        'SELECT * FROM messages WHERE channel = ? ORDER BY created_at DESC LIMIT ?',
        [channel, limit],
        (err, rows: any[]) => {
          if (err) reject(err);
          else resolve((rows || []).map((row) => this.mapRowToMessage(row)));
        }
      );
    });
  }

  async findRecent(limit: number = 100): Promise<Message[]> {
    return new Promise((resolve, reject) => {
      this.db.all(
        'SELECT * FROM messages ORDER BY created_at DESC LIMIT ?',
        [limit],
        (err, rows: any[]) => {
          if (err) reject(err);
          else resolve((rows || []).map((row) => this.mapRowToMessage(row)));
        }
      );
    });
  }

  private mapRowToMessage(row: any): Message {
    return {
      id: row.id,
      workflowRunId: row.workflow_run_id,
      fromAgentId: row.from_agent_id,
      toAgentId: row.to_agent_id,
      channel: row.channel,
      content: row.content,
      role: row.role as 'user' | 'assistant' | 'system',
      metadata: JSON.parse(row.metadata || '{}'),
      createdAt: new Date(row.created_at),
    };
  }
}
