import { Database } from 'sqlite3';
import { v4 as uuidv4 } from 'uuid';
import { Agent, AgentTool } from '@shared/types';

export class AgentRepository {
  constructor(private db: Database) {}

  async create(agent: Omit<Agent, 'id' | 'createdAt' | 'updatedAt'>): Promise<Agent> {
    const id = uuidv4();
    const now = new Date().toISOString();

    return new Promise((resolve, reject) => {
      this.db.run(
        `INSERT INTO agents (
          id, name, role, description, system_prompt, model,
          temperature, max_tokens, channels, memory_config, guardrails, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id,
          agent.name,
          agent.role,
          agent.description || null,
          agent.systemPrompt,
          agent.model,
          agent.temperature || 0.7,
          agent.maxTokens || 2000,
          JSON.stringify(agent.channels || []),
          JSON.stringify(agent.memory || {}),
          JSON.stringify(agent.guardrails || []),
          now,
          now,
        ],
        async (err) => {
          if (err) reject(err);
          else {
            const created = await this.findById(id);
            resolve(created!);
          }
        }
      );
    });
  }

  async findById(id: string): Promise<Agent | null> {
    return new Promise((resolve, reject) => {
      this.db.get(
        'SELECT * FROM agents WHERE id = ?',
        [id],
        (err, row: any) => {
          if (err) reject(err);
          else resolve(row ? this.mapRowToAgent(row) : null);
        }
      );
    });
  }

  async findAll(limit: number = 100, offset: number = 0): Promise<Agent[]> {
    return new Promise((resolve, reject) => {
      this.db.all(
        'SELECT * FROM agents ORDER BY created_at DESC LIMIT ? OFFSET ?',
        [limit, offset],
        (err, rows: any[]) => {
          if (err) reject(err);
          else resolve((rows || []).map((row) => this.mapRowToAgent(row)));
        }
      );
    });
  }

  async update(id: string, updates: Partial<Agent>): Promise<Agent> {
    const now = new Date().toISOString();
    const fields: string[] = [];
    const values: any[] = [];

    if (updates.name !== undefined) {
      fields.push('name = ?');
      values.push(updates.name);
    }
    if (updates.role !== undefined) {
      fields.push('role = ?');
      values.push(updates.role);
    }
    if (updates.systemPrompt !== undefined) {
      fields.push('system_prompt = ?');
      values.push(updates.systemPrompt);
    }
    if (updates.temperature !== undefined) {
      fields.push('temperature = ?');
      values.push(updates.temperature);
    }
    if (updates.tools !== undefined) {
      fields.push('tools_json = ?');
      values.push(JSON.stringify(updates.tools));
    }
    if (updates.channels !== undefined) {
      fields.push('channels = ?');
      values.push(JSON.stringify(updates.channels));
    }

    fields.push('updated_at = ?');
    values.push(now);
    values.push(id);

    return new Promise((resolve, reject) => {
      this.db.run(
        `UPDATE agents SET ${fields.join(', ')} WHERE id = ?`,
        values,
        async (err) => {
          if (err) reject(err);
          else {
            const updated = await this.findById(id);
            resolve(updated!);
          }
        }
      );
    });
  }

  async delete(id: string): Promise<void> {
    return new Promise((resolve, reject) => {
      this.db.run('DELETE FROM agents WHERE id = ?', [id], (err) => {
        if (err) reject(err);
        else resolve();
      });
    });
  }

  async count(): Promise<number> {
    return new Promise((resolve, reject) => {
      this.db.get('SELECT COUNT(*) as count FROM agents', (err, row: any) => {
        if (err) reject(err);
        else resolve(row?.count || 0);
      });
    });
  }

  private mapRowToAgent(row: any): Agent {
    return {
      id: row.id,
      name: row.name,
      role: row.role,
      description: row.description,
      systemPrompt: row.system_prompt,
      model: row.model,
      temperature: row.temperature,
      maxTokens: row.max_tokens,
      tools: JSON.parse(row.tools_json || '[]'),
      channels: JSON.parse(row.channels || '[]'),
      memory: JSON.parse(row.memory_config || '{}'),
      guardrails: JSON.parse(row.guardrails || '[]'),
      createdAt: new Date(row.created_at),
      updatedAt: new Date(row.updated_at),
    };
  }
}
