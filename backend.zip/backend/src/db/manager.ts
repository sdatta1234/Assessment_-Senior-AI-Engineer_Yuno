import { Database as Sqlite3Database } from 'sqlite3';
import { AgentRepository } from './repositories/AgentRepository';
import { WorkflowRepository, WorkflowRunRepository } from './repositories/WorkflowRepository';
import { MessageRepository } from './repositories/MessageRepository';

export class DatabaseManager {
  private db: Sqlite3Database;
  private agentRepo: AgentRepository;
  private workflowRepo: WorkflowRepository;
  private workflowRunRepo: WorkflowRunRepository;
  private messageRepo: MessageRepository;

  constructor(db: Sqlite3Database) {
    this.db = db;
    this.agentRepo = new AgentRepository(db);
    this.workflowRepo = new WorkflowRepository(db);
    this.workflowRunRepo = new WorkflowRunRepository(db);
    this.messageRepo = new MessageRepository(db);
  }

  get agents(): AgentRepository {
    return this.agentRepo;
  }

  get workflows(): WorkflowRepository {
    return this.workflowRepo;
  }

  get workflowRuns(): WorkflowRunRepository {
    return this.workflowRunRepo;
  }

  get messages(): MessageRepository {
    return this.messageRepo;
  }

  getDatabase(): Sqlite3Database {
    return this.db;
  }

  async close(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.db.close((err) => {
        if (err) reject(err);
        else resolve();
      });
    });
  }
}

let dbInstance: DatabaseManager | null = null;

export function getDatabase(): DatabaseManager {
  if (!dbInstance) {
    throw new Error('Database not initialized');
  }
  return dbInstance;
}

export function setDatabase(db: DatabaseManager): void {
  dbInstance = db;
}
