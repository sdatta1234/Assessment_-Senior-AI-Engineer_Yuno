import { Message } from '@shared/types';

export interface MessagingAdapter {
  name: string;
  connect(): Promise<void>;
  disconnect(): Promise<void>;
  sendMessage(agentId: string, message: string, userId: string): Promise<void>;
  handleIncoming(payload: any): Promise<void>;
  isConnected(): boolean;
}

export interface MessagingEvent {
  type: 'message' | 'status' | 'error';
  agentId?: string;
  userId?: string;
  content?: string;
  error?: string;
}

export abstract class BaseMessagingAdapter implements MessagingAdapter {
  abstract name: string;
  protected connected: boolean = false;
  protected handlers: Map<string, (event: MessagingEvent) => void> = new Map();

  async connect(): Promise<void> {
    this.connected = true;
    console.log(`${this.name} connected`);
  }

  async disconnect(): Promise<void> {
    this.connected = false;
    console.log(`${this.name} disconnected`);
  }

  abstract sendMessage(agentId: string, message: string, userId: string): Promise<void>;
  abstract handleIncoming(payload: any): Promise<void>;

  isConnected(): boolean {
    return this.connected;
  }

  on(event: string, handler: (event: MessagingEvent) => void): void {
    this.handlers.set(event, handler);
  }

  emit(event: string, data: MessagingEvent): void {
    const handler = this.handlers.get(event);
    if (handler) {
      handler(data);
    }
  }
}

export class TelegramAdapter extends BaseMessagingAdapter {
  name = 'telegram';
  private botToken?: string;
  private conversationMap: Map<string, string> = new Map(); // userId -> agentId

  constructor(botToken?: string) {
    super();
    this.botToken = botToken;
  }

  async connect(): Promise<void> {
    if (!this.botToken) {
      throw new Error('Telegram bot token not configured');
    }
    await super.connect();
    console.log('Telegram adapter initialized');
  }

  async sendMessage(agentId: string, message: string, userId: string): Promise<void> {
    if (!this.connected) {
      throw new Error('Telegram adapter not connected');
    }

    console.log(`Sending to Telegram - User: ${userId}, Message: ${message}`);

    // In production, this would call Telegram API
    // Example: POST https://api.telegram.org/bot{token}/sendMessage
    this.emit('message', {
      type: 'message',
      agentId,
      userId,
      content: message,
    });
  }

  async handleIncoming(payload: any): Promise<void> {
    // Telegram webhook payload structure
    const message = payload.message;
    if (!message) return;

    const userId = String(message.from.id);
    const text = message.text;

    // Store conversation mapping
    this.conversationMap.set(userId, payload.agent_id || 'default-agent');

    this.emit('message', {
      type: 'message',
      agentId: this.conversationMap.get(userId),
      userId,
      content: text,
    });

    console.log(`Incoming Telegram message from ${userId}: ${text}`);
  }

  setAgentMapping(userId: string, agentId: string): void {
    this.conversationMap.set(userId, agentId);
  }

  getAgentMapping(userId: string): string | undefined {
    return this.conversationMap.get(userId);
  }
}

export class WhatsAppAdapter extends BaseMessagingAdapter {
  name = 'whatsapp';
  private accountSid?: string;
  private authToken?: string;
  private phoneNumber?: string;
  private conversationMap: Map<string, string> = new Map();

  constructor(accountSid?: string, authToken?: string, phoneNumber?: string) {
    super();
    this.accountSid = accountSid;
    this.authToken = authToken;
    this.phoneNumber = phoneNumber;
  }

  async connect(): Promise<void> {
    if (!this.accountSid || !this.authToken || !this.phoneNumber) {
      throw new Error('WhatsApp credentials not configured');
    }
    await super.connect();
    console.log('WhatsApp adapter initialized');
  }

  async sendMessage(agentId: string, message: string, userId: string): Promise<void> {
    if (!this.connected) {
      throw new Error('WhatsApp adapter not connected');
    }

    console.log(`Sending to WhatsApp - User: ${userId}, Message: ${message}`);

    // In production, this would call Twilio API
    // Example: POST https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/Messages.json
    this.emit('message', {
      type: 'message',
      agentId,
      userId,
      content: message,
    });
  }

  async handleIncoming(payload: any): Promise<void> {
    // Twilio webhook payload structure
    const from = payload.From;
    const body = payload.Body;

    if (!from || !body) return;

    const userId = from.replace('whatsapp:', '');
    const agentId = this.conversationMap.get(userId) || 'default-agent';

    this.emit('message', {
      type: 'message',
      agentId,
      userId,
      content: body,
    });

    console.log(`Incoming WhatsApp message from ${userId}: ${body}`);
  }

  setAgentMapping(userId: string, agentId: string): void {
    this.conversationMap.set(userId, agentId);
  }

  getAgentMapping(userId: string): string | undefined {
    return this.conversationMap.get(userId);
  }
}

export class SlackAdapter extends BaseMessagingAdapter {
  name = 'slack';
  private botToken?: string;
  private signingSecret?: string;
  private conversationMap: Map<string, string> = new Map();

  constructor(botToken?: string, signingSecret?: string) {
    super();
    this.botToken = botToken;
    this.signingSecret = signingSecret;
  }

  async connect(): Promise<void> {
    if (!this.botToken || !this.signingSecret) {
      throw new Error('Slack credentials not configured');
    }
    await super.connect();
    console.log('Slack adapter initialized');
  }

  async sendMessage(agentId: string, message: string, userId: string): Promise<void> {
    if (!this.connected) {
      throw new Error('Slack adapter not connected');
    }

    console.log(`Sending to Slack - User: ${userId}, Message: ${message}`);

    this.emit('message', {
      type: 'message',
      agentId,
      userId,
      content: message,
    });
  }

  async handleIncoming(payload: any): Promise<void> {
    // Slack event payload structure
    const event = payload.event;
    if (!event || event.type !== 'message' || event.bot_id) return;

    const userId = event.user;
    const text = event.text;

    if (!userId || !text) return;

    const agentId = this.conversationMap.get(userId) || 'default-agent';

    this.emit('message', {
      type: 'message',
      agentId,
      userId,
      content: text,
    });

    console.log(`Incoming Slack message from ${userId}: ${text}`);
  }

  setAgentMapping(userId: string, agentId: string): void {
    this.conversationMap.set(userId, agentId);
  }

  getAgentMapping(userId: string): string | undefined {
    return this.conversationMap.get(userId);
  }
}

// Adapter registry
export class MessagingAdapterRegistry {
  private adapters: Map<string, MessagingAdapter> = new Map();

  register(adapter: MessagingAdapter): void {
    this.adapters.set(adapter.name, adapter);
    console.log(`Registered messaging adapter: ${adapter.name}`);
  }

  get(name: string): MessagingAdapter | undefined {
    return this.adapters.get(name);
  }

  getAll(): MessagingAdapter[] {
    return Array.from(this.adapters.values());
  }

  async connectAll(): Promise<void> {
    for (const adapter of this.adapters.values()) {
      try {
        await adapter.connect();
      } catch (error) {
        console.error(`Failed to connect ${adapter.name}:`, error);
      }
    }
  }

  async disconnectAll(): Promise<void> {
    for (const adapter of this.adapters.values()) {
      try {
        await adapter.disconnect();
      } catch (error) {
        console.error(`Failed to disconnect ${adapter.name}:`, error);
      }
    }
  }
}

let adapterRegistry: MessagingAdapterRegistry | null = null;

export function getMessagingAdapterRegistry(): MessagingAdapterRegistry {
  if (!adapterRegistry) {
    adapterRegistry = new MessagingAdapterRegistry();
  }
  return adapterRegistry;
}
