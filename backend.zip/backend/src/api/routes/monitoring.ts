import { Router, Request, Response } from 'express';
import { getAgentRuntime } from '../../agents/runtime';
import { getDatabase } from '../../db/manager';

const router = Router();

// GET /api/monitoring/logs - Get system logs
router.get('/logs', async (req: Request, res: Response) => {
  try {
    const db = getDatabase();
    const limit = parseInt(req.query.limit as string) || 100;
    const level = req.query.level as string;

    // For now, return mock data - full logging implementation would store in DB
    const logs = [
      {
        timestamp: new Date(),
        level: 'info',
        message: 'Server started successfully',
        component: 'core',
      },
      {
        timestamp: new Date(),
        level: 'info',
        message: 'Database initialized',
        component: 'database',
      },
    ];

    res.json({
      success: true,
      data: logs.slice(-limit),
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to fetch logs',
    });
  }
});

// GET /api/monitoring/metrics - Get metrics
router.get('/metrics', (req: Request, res: Response) => {
  try {
    const runtime = getAgentRuntime();
    const activeAgents = runtime.getActiveAgents();

    const metrics = {
      timestamp: new Date(),
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      activeAgents: activeAgents.length,
      cpuUsage: process.cpuUsage(),
    };

    res.json({
      success: true,
      data: metrics,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to fetch metrics',
    });
  }
});

// GET /api/monitoring/agents/:agentId/stats - Get agent stats
router.get('/agents/:agentId/stats', (req: Request, res: Response) => {
  try {
    const runtime = getAgentRuntime();
    const stats = runtime.getAgentStats(req.params.agentId);

    if (!stats) {
      return res.status(404).json({
        success: false,
        error: 'Agent not found',
      });
    }

    res.json({
      success: true,
      data: stats,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to fetch agent stats',
    });
  }
});

// GET /api/monitoring/health - System health
router.get('/health', (req: Request, res: Response) => {
  try {
    const runtime = getAgentRuntime();

    const health = {
      database: 'up',
      runtime: 'up',
      timestamp: new Date(),
      activeAgents: runtime.getActiveAgents().length,
      status: 'healthy',
    };

    res.json({
      success: true,
      data: health,
    });
  } catch (error) {
    res.status(503).json({
      success: false,
      error: error instanceof Error ? error.message : 'System unhealthy',
    });
  }
});

export default router;
