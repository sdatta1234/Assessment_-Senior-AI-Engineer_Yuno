import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { getDatabase } from '../../db/manager';
import { getAgentRuntime } from '../../agents/runtime';
import { broadcastEvent } from '../../ws/handler';

const router = Router();

// GET /api/agents - List all agents
router.get('/', async (req: Request, res: Response) => {
  try {
    const db = getDatabase();
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const offset = (page - 1) * limit;

    const agents = await db.agents.findAll(limit, offset);
    const count = await db.agents.count();

    res.json({
      success: true,
      data: agents,
      total: count,
      page,
      pageSize: limit,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to fetch agents',
    });
  }
});

// POST /api/agents - Create new agent
router.post('/', async (req: Request, res: Response) => {
  try {
    const { name, role, systemPrompt, model, tools = [], channels = [], temperature = 0.7, maxTokens = 2000 } = req.body;

    if (!name || !role || !systemPrompt || !model) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: name, role, systemPrompt, model',
      });
    }

    const db = getDatabase();
    const agent = await db.agents.create({
      name,
      role,
      systemPrompt,
      model,
      tools,
      channels,
      temperature,
      maxTokens,
    });

    // Initialize agent in runtime
    const runtime = getAgentRuntime();
    runtime.initializeAgent(agent);

    // Broadcast event
    broadcastEvent({
      type: 'agent:created',
      payload: agent,
      timestamp: new Date(),
    });

    res.status(201).json({
      success: true,
      data: agent,
      message: 'Agent created successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to create agent',
    });
  }
});

// GET /api/agents/:id - Get agent by ID
router.get('/:id', async (req: Request, res: Response) => {
  try {
    const db = getDatabase();
    const agent = await db.agents.findById(req.params.id);

    if (!agent) {
      return res.status(404).json({
        success: false,
        error: 'Agent not found',
      });
    }

    res.json({
      success: true,
      data: agent,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to fetch agent',
    });
  }
});

// PUT /api/agents/:id - Update agent
router.put('/:id', async (req: Request, res: Response) => {
  try {
    const db = getDatabase();
    const agent = await db.agents.update(req.params.id, req.body);

    // Update runtime
    const runtime = getAgentRuntime();
    runtime.deleteAgent(req.params.id);
    runtime.initializeAgent(agent);

    // Broadcast event
    broadcastEvent({
      type: 'agent:updated',
      payload: agent,
      timestamp: new Date(),
    });

    res.json({
      success: true,
      data: agent,
      message: 'Agent updated successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to update agent',
    });
  }
});

// DELETE /api/agents/:id - Delete agent
router.delete('/:id', async (req: Request, res: Response) => {
  try {
    const db = getDatabase();
    await db.agents.delete(req.params.id);

    // Remove from runtime
    const runtime = getAgentRuntime();
    runtime.deleteAgent(req.params.id);

    // Broadcast event
    broadcastEvent({
      type: 'agent:deleted',
      payload: { agentId: req.params.id },
      timestamp: new Date(),
    });

    res.json({
      success: true,
      message: 'Agent deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to delete agent',
    });
  }
});

// GET /api/agents/:id/stats - Get agent statistics
router.get('/:id/stats', async (req: Request, res: Response) => {
  try {
    const runtime = getAgentRuntime();
    const stats = runtime.getAgentStats(req.params.id);

    if (!stats) {
      return res.status(404).json({
        success: false,
        error: 'Agent not found',
      });
    }

    res.json({
      success: true,
      data: stats,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to fetch agent stats',
    });
  }
});

export default router;
