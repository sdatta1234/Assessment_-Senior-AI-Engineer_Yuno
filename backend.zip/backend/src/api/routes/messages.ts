import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { getDatabase } from '../../db/manager';
import { broadcastEvent } from '../../ws/handler';

const router = Router();

// GET /api/messages - Get message history
router.get('/', async (req: Request, res: Response) => {
  try {
    const db = getDatabase();
    const agentId = req.query.agentId as string;
    const channel = req.query.channel as string;
    const limit = parseInt(req.query.limit as string) || 50;

    let messages;
    if (agentId) {
      messages = await db.messages.findByAgentId(agentId, limit);
    } else if (channel) {
      messages = await db.messages.findByChannel(channel, limit);
    } else {
      messages = await db.messages.findRecent(limit);
    }

    res.json({
      success: true,
      data: messages,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to fetch messages',
    });
  }
});

// POST /api/messages - Send message
router.post('/', async (req: Request, res: Response) => {
  try {
    const { toAgentId, channel = 'internal', content, role = 'user' } = req.body;

    if (!content || (!toAgentId && !channel)) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: content, and either toAgentId or channel',
      });
    }

    const db = getDatabase();
    const message = await db.messages.create({
      toAgentId,
      channel,
      content,
      role: role as 'user' | 'assistant' | 'system',
    });

    // Broadcast event
    broadcastEvent({
      type: 'message:sent',
      payload: message,
      timestamp: new Date(),
    });

    res.status(201).json({
      success: true,
      data: message,
      message: 'Message sent successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to send message',
    });
  }
});

// GET /api/messages/:conversationId - Get conversation
router.get('/:conversationId', async (req: Request, res: Response) => {
  try {
    const db = getDatabase();
    const messages = await db.messages.findByWorkflowRunId(req.params.conversationId);

    res.json({
      success: true,
      data: messages,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to fetch conversation',
    });
  }
});

export default router;
