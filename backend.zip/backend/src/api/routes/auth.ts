import { Router, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { getDatabase } from '../../db/manager';

const router = Router();

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-key-change-in-production';

// POST /api/auth/register - Register user
router.post('/register', async (req: Request, res: Response) => {
  try {
    const { email, password, name } = req.body;

    if (!email || !password || !name) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: email, password, name',
      });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // For now, store in simple memory (would use User repository in real implementation)
    const user = {
      id: uuidv4(),
      email,
      name,
      passwordHash: hashedPassword,
      role: 'user',
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    // Generate token
    const token = jwt.sign(
      { userId: user.id, email: user.email },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.status(201).json({
      success: true,
      data: {
        user: { id: user.id, email: user.email, name: user.name },
        token,
      },
      message: 'User registered successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to register user',
    });
  }
});

// POST /api/auth/login - Login user
router.post('/login', async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: email, password',
      });
    }

    // Mock user lookup (in real implementation, would query User repository)
    const user = {
      id: uuidv4(),
      email,
      name: email.split('@')[0],
      passwordHash: await bcrypt.hash('demo-password', 10),
      role: 'user',
    };

    // Simple validation (in production, would verify against stored hash)
    if (password === 'demo-password' || password.length > 0) {
      const token = jwt.sign(
        { userId: user.id, email: user.email },
        JWT_SECRET,
        { expiresIn: '24h' }
      );

      return res.json({
        success: true,
        data: {
          user: { id: user.id, email: user.email, name: user.name },
          token,
        },
        message: 'Login successful',
      });
    }

    res.status(401).json({
      success: false,
      error: 'Invalid credentials',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to login',
    });
  }
});

// POST /api/auth/logout - Logout user
router.post('/logout', (req: Request, res: Response) => {
  res.json({
    success: true,
    message: 'Logout successful',
  });
});

// GET /api/auth/me - Get current user
router.get('/me', (req: Request, res: Response) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];

    if (!token) {
      return res.status(401).json({
        success: false,
        error: 'No token provided',
      });
    }

    const decoded = jwt.verify(token, JWT_SECRET) as any;
    res.json({
      success: true,
      data: {
        userId: decoded.userId,
        email: decoded.email,
      },
    });
  } catch (error) {
    res.status(401).json({
      success: false,
      error: 'Invalid token',
    });
  }
});

export default router;
