import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { getDatabase } from '../../db/manager';
import { getWorkflowExecutor } from '../../workflows/executor';
import { broadcastEvent } from '../../ws/handler';

const router = Router();

// GET /api/workflows - List all workflows
router.get('/', async (req: Request, res: Response) => {
  try {
    const db = getDatabase();
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const offset = (page - 1) * limit;

    const workflows = await db.workflows.findAll(limit, offset);

    res.json({
      success: true,
      data: workflows,
      page,
      pageSize: limit,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to fetch workflows',
    });
  }
});

// POST /api/workflows - Create workflow
router.post('/', async (req: Request, res: Response) => {
  try {
    const { name, description, nodes, edges } = req.body;

    if (!name || !nodes || !edges) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields: name, nodes, edges',
      });
    }

    const db = getDatabase();
    const workflow = await db.workflows.create({
      name,
      description,
      nodes,
      edges,
    });

    // Broadcast event
    broadcastEvent({
      type: 'agent:created',
      payload: workflow,
      timestamp: new Date(),
    });

    res.status(201).json({
      success: true,
      data: workflow,
      message: 'Workflow created successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to create workflow',
    });
  }
});

// GET /api/workflows/:id - Get workflow
router.get('/:id', async (req: Request, res: Response) => {
  try {
    const db = getDatabase();
    const workflow = await db.workflows.findById(req.params.id);

    if (!workflow) {
      return res.status(404).json({
        success: false,
        error: 'Workflow not found',
      });
    }

    res.json({
      success: true,
      data: workflow,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to fetch workflow',
    });
  }
});

// PUT /api/workflows/:id - Update workflow
router.put('/:id', async (req: Request, res: Response) => {
  try {
    const db = getDatabase();
    const workflow = await db.workflows.update(req.params.id, req.body);

    res.json({
      success: true,
      data: workflow,
      message: 'Workflow updated successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to update workflow',
    });
  }
});

// DELETE /api/workflows/:id - Delete workflow
router.delete('/:id', async (req: Request, res: Response) => {
  try {
    const db = getDatabase();
    await db.workflows.delete(req.params.id);

    res.json({
      success: true,
      message: 'Workflow deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to delete workflow',
    });
  }
});

// POST /api/workflows/:id/execute - Execute workflow
router.post('/:id/execute', async (req: Request, res: Response) => {
  try {
    const db = getDatabase();
    const workflow = await db.workflows.findById(req.params.id);

    if (!workflow) {
      return res.status(404).json({
        success: false,
        error: 'Workflow not found',
      });
    }

    // Execute workflow
    const executor = getWorkflowExecutor();
    const result = await executor.executeWorkflow(
      workflow.id,
      workflow.nodes,
      workflow.edges,
      req.body.input
    );

    res.json({
      success: true,
      data: {
        runId: result.runId,
        workflowId: result.workflowId,
        status: result.status,
        startTime: result.startTime,
        endTime: result.endTime,
      },
      message: 'Workflow execution started',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to execute workflow',
    });
  }
});

// GET /api/workflows/:id/runs - Get workflow runs
router.get('/:id/runs', async (req: Request, res: Response) => {
  try {
    const db = getDatabase();
    const runs = await db.workflowRuns.findByWorkflowId(req.params.id);

    res.json({
      success: true,
      data: runs,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to fetch workflow runs',
    });
  }
});

export default router;
