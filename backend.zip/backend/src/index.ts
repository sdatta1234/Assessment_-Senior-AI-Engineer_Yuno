import express, { Express, Request, Response } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import path from 'path';

// Load environment variables
dotenv.config({ path: path.resolve(__dirname, '../../.env') });

// Import routes
import agentRoutes from './api/routes/agents';
import workflowRoutes from './api/routes/workflows';
import messageRoutes from './api/routes/messages';
import authRoutes from './api/routes/auth';
import monitoringRoutes from './api/routes/monitoring';

// Import database initialization
import { initializeDatabase } from './db/init';
import { DatabaseManager, setDatabase } from './db/manager';
import { getAgentRuntime } from './agents/runtime';
import { getMessagingAdapterRegistry, TelegramAdapter, WhatsAppAdapter } from './messaging/adapters';

// Import WebSocket handler
import { setupWebSocket } from './ws/handler';

// Initialize Express app
const app: Express = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health check endpoint
app.get('/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date() });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/agents', agentRoutes);
app.use('/api/workflows', workflowRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/monitoring', monitoringRoutes);

// 404 handler
app.use((req: Request, res: Response) => {
  res.status(404).json({ 
    success: false, 
    error: 'Route not found' 
  });
});

// Create HTTP server for WebSocket support
const server = createServer(app);

// Setup WebSocket server
const wss = new WebSocketServer({ server });
setupWebSocket(wss);

// Initialize database and start server
(async () => {
  try {
    console.log('Initializing database...');
    await initializeDatabase();
    console.log('✓ Database initialized successfully');

    // Initialize agent runtime
    const runtime = getAgentRuntime();
    console.log('✓ Agent runtime initialized');

    // Initialize messaging adapters
    const adapterRegistry = getMessagingAdapterRegistry();
    if (process.env.TELEGRAM_BOT_TOKEN) {
      const telegramAdapter = new TelegramAdapter(process.env.TELEGRAM_BOT_TOKEN);
      adapterRegistry.register(telegramAdapter);
      console.log('✓ Telegram adapter registered');
    }

    if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN) {
      const whatsappAdapter = new WhatsAppAdapter(
        process.env.TWILIO_ACCOUNT_SID,
        process.env.TWILIO_AUTH_TOKEN,
        process.env.TWILIO_PHONE_NUMBER
      );
      adapterRegistry.register(whatsappAdapter);
      console.log('✓ WhatsApp adapter registered');
    }

    server.listen(PORT, () => {
      console.log(`\n✓ Server running on http://localhost:${PORT}`);
      console.log(`✓ WebSocket ready on ws://localhost:${PORT}`);
      console.log(`✓ Health check: http://localhost:${PORT}/health`);
      console.log(`✓ API available at http://localhost:${PORT}/api\n`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
})();

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('\nShutting down gracefully...');
  const adapterRegistry = getMessagingAdapterRegistry();
  await adapterRegistry.disconnectAll();
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

export default app;
