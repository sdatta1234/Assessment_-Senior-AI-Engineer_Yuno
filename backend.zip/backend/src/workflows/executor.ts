import { v4 as uuidv4 } from 'uuid';
import { WorkflowNode, WorkflowEdge, Message } from '@shared/types';
import { getAgentRuntime } from '../agents/runtime';
import { getDatabase } from '../db/manager';
import { broadcastEvent } from '../ws/handler';

export interface WorkflowExecutionContext {
  workflowId: string;
  runId: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  currentNode?: string;
  nodeResults: Map<string, any>;
  messages: Message[];
  startTime: Date;
  endTime?: Date;
  error?: string;
}

export class WorkflowExecutor {
  /**
   * Execute a workflow
   */
  async executeWorkflow(
    workflowId: string,
    nodes: WorkflowNode[],
    edges: WorkflowEdge[],
    input?: any
  ): Promise<WorkflowExecutionContext> {
    const db = getDatabase();
    const runtime = getAgentRuntime();

    // Create execution context
    const context: WorkflowExecutionContext = {
      workflowId,
      runId: uuidv4(),
      status: 'running',
      nodeResults: new Map(),
      messages: [],
      startTime: new Date(),
    };

    try {
      // Create workflow run in database
      const run = await db.workflowRuns.create(workflowId);
      context.runId = run.id;

      // Emit start event
      broadcastEvent({
        type: 'workflow:started',
        payload: { workflowId, runId: context.runId },
        timestamp: new Date(),
      });

      // Find start node
      let currentNodeId = this.findStartNode(nodes);
      if (!currentNodeId) {
        throw new Error('No start node found in workflow');
      }

      const visited = new Set<string>();
      const maxIterations = 100; // Prevent infinite loops
      let iterations = 0;

      // Execute nodes
      while (currentNodeId && iterations < maxIterations) {
        iterations++;
        visited.add(currentNodeId);

        const node = nodes.find((n) => n.id === currentNodeId);
        if (!node) {
          throw new Error(`Node ${currentNodeId} not found`);
        }

        context.currentNode = currentNodeId;

        // Execute node based on type
        try {
          switch (node.type) {
            case 'trigger':
              context.nodeResults.set(currentNodeId, { triggered: true, input });
              break;

            case 'agent':
              const agentResult = await this.executeAgentNode(node, context, input);
              context.nodeResults.set(currentNodeId, agentResult);
              break;

            case 'condition':
              const conditionResult = await this.evaluateCondition(node, context);
              context.nodeResults.set(currentNodeId, conditionResult);
              break;

            case 'parallel':
              const parallelResult = await this.executeParallel(node, nodes, edges, context);
              context.nodeResults.set(currentNodeId, parallelResult);
              break;

            case 'end':
              context.nodeResults.set(currentNodeId, { ended: true });
              currentNodeId = undefined;
              continue;
          }

          // Emit node executed event
          broadcastEvent({
            type: 'workflow:started',
            payload: { workflowId, nodeId: currentNodeId, status: 'completed' },
            timestamp: new Date(),
          });
        } catch (nodeError) {
          console.error(`Error executing node ${currentNodeId}:`, nodeError);
          context.nodeResults.set(currentNodeId, { error: String(nodeError) });
        }

        // Find next node
        const nextEdge = edges.find((e) => e.source === currentNodeId);
        if (nextEdge) {
          // Check condition if exists
          if (nextEdge.condition) {
            const conditionMet = await this.evaluateCondition(
              { id: nextEdge.id, type: 'condition', data: { condition: nextEdge.condition } },
              context
            );
            if (!conditionMet) {
              // Find alternate edge
              const alternateEdge = edges.find(
                (e) =>
                  e.source === currentNodeId &&
                  e.id !== nextEdge.id &&
                  !e.condition
              );
              currentNodeId = alternateEdge?.target;
            } else {
              currentNodeId = nextEdge.target;
            }
          } else {
            currentNodeId = nextEdge.target;
          }
        } else {
          currentNodeId = undefined;
        }
      }

      if (iterations >= maxIterations) {
        throw new Error('Workflow execution exceeded maximum iterations (infinite loop detected)');
      }

      context.status = 'completed';
      context.endTime = new Date();

      // Update in database
      await db.workflowRuns.updateStatus(context.runId, 'completed');

      // Emit completion event
      broadcastEvent({
        type: 'workflow:completed',
        payload: { workflowId, runId: context.runId, results: context.nodeResults },
        timestamp: new Date(),
      });
    } catch (error) {
      context.status = 'failed';
      context.error = error instanceof Error ? error.message : String(error);
      context.endTime = new Date();

      // Update in database
      await db.workflowRuns.updateStatus(context.runId, 'failed');

      // Emit error event
      broadcastEvent({
        type: 'workflow:completed',
        payload: { workflowId, runId: context.runId, status: 'failed', error: context.error },
        timestamp: new Date(),
      });
    }

    return context;
  }

  /**
   * Execute an agent node
   */
  private async executeAgentNode(node: WorkflowNode, context: WorkflowExecutionContext, input: any): Promise<any> {
    const agentId = node.data.agentId;
    if (!agentId) {
      throw new Error('Agent node missing agentId');
    }

    const runtime = getAgentRuntime();
    const agent = runtime.getAgent(agentId);
    if (!agent) {
      throw new Error(`Agent ${agentId} not initialized`);
    }

    // Add message to agent
    runtime.addMessage(agentId, 'user', input || `Execute task from node ${node.id}`);

    // Simulate agent processing
    const response = `Agent ${agent.role} processed task and returned result`;
    runtime.addMessage(agentId, 'assistant', response);

    return {
      agentId,
      executed: true,
      response,
      timestamp: new Date(),
    };
  }

  /**
   * Evaluate a condition node
   */
  private async evaluateCondition(node: WorkflowNode, context: WorkflowExecutionContext): Promise<boolean> {
    const condition = node.data.condition || node.data.config?.condition;
    if (!condition) {
      return true; // No condition = always true
    }

    try {
      // Simple condition evaluation (can be extended)
      return eval(condition) === true;
    } catch (error) {
      console.error('Error evaluating condition:', error);
      return false;
    }
  }

  /**
   * Execute parallel nodes
   */
  private async executeParallel(
    node: WorkflowNode,
    nodes: WorkflowNode[],
    edges: WorkflowEdge[],
    context: WorkflowExecutionContext
  ): Promise<any> {
    // Find child nodes
    const childEdges = edges.filter((e) => e.source === node.id);
    const childNodes = childEdges.map((e) => nodes.find((n) => n.id === e.target)).filter(Boolean);

    // Execute in parallel
    const results = await Promise.allSettled(
      childNodes.map((childNode) => this.executeNode(childNode!, nodes, edges, context))
    );

    return {
      parallel: true,
      nodeCount: childNodes.length,
      results: results.map((r) => (r.status === 'fulfilled' ? r.value : { error: r.reason })),
    };
  }

  /**
   * Execute a single node (helper)
   */
  private async executeNode(
    node: WorkflowNode,
    nodes: WorkflowNode[],
    edges: WorkflowEdge[],
    context: WorkflowExecutionContext
  ): Promise<any> {
    switch (node.type) {
      case 'agent':
        return this.executeAgentNode(node, context, context.nodeResults.get('trigger-1'));
      case 'condition':
        return this.evaluateCondition(node, context);
      default:
        return { executed: true };
    }
  }

  /**
   * Find start node in workflow
   */
  private findStartNode(nodes: WorkflowNode[]): string | undefined {
    const triggerNode = nodes.find((n) => n.type === 'trigger');
    return triggerNode?.id;
  }
}

// Singleton instance
let executorInstance: WorkflowExecutor | null = null;

export function getWorkflowExecutor(): WorkflowExecutor {
  if (!executorInstance) {
    executorInstance = new WorkflowExecutor();
  }
  return executorInstance;
}
